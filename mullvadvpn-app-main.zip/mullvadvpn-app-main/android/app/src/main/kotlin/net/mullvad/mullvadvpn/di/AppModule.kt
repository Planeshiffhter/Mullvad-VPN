package net.mullvad.mullvadvpn.di

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.system.Os
import androidx.core.app.NotificationManagerCompat
import androidx.datastore.core.DataStore
import androidx.datastore.core.handlers.ReplaceFileCorruptionHandler
import androidx.datastore.dataStore
import co.touchlab.kermit.Logger
import java.io.File
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.MainScope
import net.mullvad.mullvadvpn.BuildConfig
import net.mullvad.mullvadvpn.feature.appicon.impl.obfuscation.AppObfuscationRepository
import net.mullvad.mullvadvpn.feature.language.impl.LanguageRepository
import net.mullvad.mullvadvpn.lib.common.constant.GRPC_SOCKET_FILE_NAME
import net.mullvad.mullvadvpn.lib.common.constant.GRPC_SOCKET_FILE_NAMED_ARGUMENT
import net.mullvad.mullvadvpn.lib.endpoint.ApiEndpointFromIntentHolder
import net.mullvad.mullvadvpn.lib.endpoint.ApiEndpointOverride
import net.mullvad.mullvadvpn.lib.grpc.ManagementService
import net.mullvad.mullvadvpn.lib.model.BuildVersion
import net.mullvad.mullvadvpn.lib.model.NotificationChannel
import net.mullvad.mullvadvpn.lib.pushnotification.NotificationChannelFactory
import net.mullvad.mullvadvpn.lib.pushnotification.NotificationManager
import net.mullvad.mullvadvpn.lib.pushnotification.NotificationProvider
import net.mullvad.mullvadvpn.lib.pushnotification.ScheduleNotificationAlarmUseCase
import net.mullvad.mullvadvpn.lib.pushnotification.accountexpiry.AccountExpiryNotificationProvider
import net.mullvad.mullvadvpn.lib.pushnotification.tunnelstate.TunnelStateNotificationProvider
import net.mullvad.mullvadvpn.lib.repository.AccountRepository
import net.mullvad.mullvadvpn.lib.repository.ConnectionProxy
import net.mullvad.mullvadvpn.lib.repository.DeviceRepository
import net.mullvad.mullvadvpn.lib.repository.LocaleRepository
import net.mullvad.mullvadvpn.lib.repository.RelayLocationTranslationRepository
import net.mullvad.mullvadvpn.lib.usecase.AccountExpiryNotificationActionUseCase
import net.mullvad.mullvadvpn.lib.userpreferences.UserPreferences
import net.mullvad.mullvadvpn.lib.userpreferences.UserPreferencesMigration
import net.mullvad.mullvadvpn.lib.userpreferences.UserPreferencesRepository
import net.mullvad.mullvadvpn.lib.userpreferences.UserPreferencesSerializer
import org.koin.android.ext.koin.androidContext
import org.koin.core.module.dsl.createdAtStart
import org.koin.core.module.dsl.withOptions
import org.koin.core.qualifier.named
import org.koin.dsl.bind
import org.koin.dsl.module

val appModule = module {
    single(named(GRPC_SOCKET_FILE_NAMED_ARGUMENT)) {
        File(androidContext().noBackupFilesDir, GRPC_SOCKET_FILE_NAME)
    }
    single {
        ManagementService(
            rpcSocketFile = get(named(GRPC_SOCKET_FILE_NAMED_ARGUMENT)),
            extensiveLogging = BuildConfig.DEBUG,
            scope = MainScope(),
            ioDispatcher = Dispatchers.IO,
        )
    }
    single { ApplicationScope.createDoNotCallUseDiInstead() }

    single { androidContext().resources }
    single { androidContext().userPreferencesStore }
    single { BuildVersion(BuildConfig.VERSION_NAME, BuildConfig.VERSION_CODE) }
    single { ApiEndpointFromIntentHolder() }
    single { AccountRepository(get(), get()) }
    single { DeviceRepository(get()) }
    single { UserPreferencesRepository(get(), get()) }
    single { ConnectionProxy(androidContext(), get(), get()) }
    single { LocaleRepository(get()) }
    single { RelayLocationTranslationRepository(get(), get(), MainScope()) }
    single { ScheduleNotificationAlarmUseCase(androidContext(), get()) }
    single { AccountExpiryNotificationActionUseCase(get(), get()) }
    // TODO Move these back to UiModule when fixDisableBug is removed
    single { AppObfuscationRepository(get(), get()) }
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        single { LanguageRepository(androidContext()) }
    }
    single<PackageManager> { androidContext().packageManager }

    single { NotificationChannel.TunnelUpdates } bind NotificationChannel::class
    single { NotificationChannel.AccountUpdates } bind NotificationChannel::class
    single { NotificationChannelFactory(get(), get(), getAll()) } withOptions { createdAtStart() }
    single { NotificationManagerCompat.from(androidContext()) }
    single { NotificationManager(get(), getAll(), get(), MainScope()) } withOptions
        {
            createdAtStart()
        }
    single {
        TunnelStateNotificationProvider(
            androidContext(),
            get(),
            get(),
            get(),
            get<NotificationChannel.TunnelUpdates>().id,
            MainScope(),
        )
    } bind NotificationProvider::class
    single { AccountExpiryNotificationProvider(get<NotificationChannel.AccountUpdates>().id) } bind
        NotificationProvider::class
    if (BuildConfig.FLAVOR_infrastructure != "prod") {
        single<ApiEndpointOverride> {
            ApiEndpointOverride(
                hostname = BuildConfig.API_ENDPOINT,
                address = BuildConfig.API_IP,
                sigsumTrustedPubkeys = BuildConfig.SIGSUM_TRUSTED_PUBKEYS,
            )
        }

        // If we override the endpoint we should also set the
        // Override the MULLVAD_CONNCHECK_HOST used by the daemon.
        if (BuildConfig.AM_I_URL.isNotEmpty()) {
            Os.setenv("MULLVAD_CONNCHECK_HOST", BuildConfig.AM_I_URL, true)
        }
    }
}

private val Context.userPreferencesStore: DataStore<UserPreferences> by
    dataStore(
        fileName = APP_PREFERENCES_NAME,
        serializer = UserPreferencesSerializer,
        produceMigrations = { UserPreferencesMigration.migrations(it, APP_PREFERENCES_NAME) },
        corruptionHandler =
            ReplaceFileCorruptionHandler {
                // HACK: https://issuetracker.google.com/issues/346197747
                // Due to known issue in DataStore the settings file sometimes get corrupted, to
                // avoid users getting stuck in a crash loop we reset the settings file.
                Logger.e(throwable = it) {
                    "Corruption of DataStore file occurred, restoring preferences file"
                }
                UserPreferences.getDefaultInstance()
            },
    )

class ApplicationScope private constructor(private val cs: CoroutineScope) : CoroutineScope by cs {
    companion object {
        fun createDoNotCallUseDiInstead(): ApplicationScope = ApplicationScope(MainScope())
    }
}
