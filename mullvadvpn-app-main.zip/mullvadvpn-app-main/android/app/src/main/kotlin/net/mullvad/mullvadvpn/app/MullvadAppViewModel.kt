package net.mullvad.mullvadvpn.app

import androidx.lifecycle.Lifecycle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlin.time.Duration.Companion.seconds
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.shareIn
import kotlinx.coroutines.launch
import net.mullvad.mullvadvpn.core.NavKey2
import net.mullvad.mullvadvpn.lib.grpc.GrpcConnectivityState
import net.mullvad.mullvadvpn.lib.grpc.ManagementService
import net.mullvad.mullvadvpn.lib.repository.ConnectionProxy
import net.mullvad.mullvadvpn.screen.navigation.SplashNavKey

private val noServiceNavKeys = listOf(SplashNavKey)

class MullvadAppViewModel(
    private val connectionProxy: ConnectionProxy,
    managementService: ManagementService,
    activityLifecycle: Lifecycle,
) : ViewModel() {

    private val backStackFlow: MutableStateFlow<List<NavKey2>> = MutableStateFlow(emptyList())

    fun setCurrentBackStack(backStack: List<NavKey2>) {
        backStackFlow.value = backStack
    }

    @OptIn(FlowPreview::class)
    val uiSideEffect =
        combine(
                activityLifecycle.currentStateFlow,
                managementService.connectionState,
                backStackFlow,
            ) { event, connEvent, backStack ->
                toDaemonState(event, connEvent, backStack.lastOrNull())
            }
            .map { state ->
                when (state) {
                    is DaemonState.Show -> DaemonScreenEvent.Show
                    is DaemonState.Hidden.Ignored -> DaemonScreenEvent.Remove
                    DaemonState.Hidden.Connected -> DaemonScreenEvent.Remove
                }
            }
            .distinctUntilChanged()
            // We debounce any disconnected state to let the UI have some time to connect after a
            // onStart/onStop event.
            .debounce {
                when (it) {
                    is DaemonScreenEvent.Remove -> 0.seconds
                    is DaemonScreenEvent.Show -> SERVICE_DISCONNECT_DEBOUNCE
                }
            }
            .distinctUntilChanged()
            .shareIn(viewModelScope, SharingStarted.Eagerly)

    private fun toDaemonState(
        lifecycleEvent: Lifecycle.State,
        serviceState: GrpcConnectivityState,
        currentDestination: NavKey2?,
    ): DaemonState {
        // In these destinations we don't care about showing the NoDaemonScreen
        if (currentDestination in noServiceNavKeys) {
            return DaemonState.Hidden.Ignored
        }

        return if (lifecycleEvent.isAtLeast(Lifecycle.State.STARTED)) {
            // If we are started we want to show the overlay if we are not connected to daemon
            when (serviceState) {
                GrpcConnectivityState.Connecting,
                GrpcConnectivityState.Closed,
                GrpcConnectivityState.Failed -> DaemonState.Show
                GrpcConnectivityState.Ready -> DaemonState.Hidden.Connected
            }
        } else {
            // If we are stopped we intentionally stop service and don't care about showing overlay.
            DaemonState.Hidden.Ignored
        }
    }

    fun connect() {
        viewModelScope.launch { connectionProxy.connectWithoutPermissionCheck() }
    }

    companion object {
        private val SERVICE_DISCONNECT_DEBOUNCE = 2.seconds
    }
}

sealed interface DaemonState {
    data object Show : DaemonState

    sealed interface Hidden : DaemonState {
        data object Ignored : Hidden

        data object Connected : Hidden
    }
}

sealed interface DaemonScreenEvent {
    data object Show : DaemonScreenEvent

    data object Remove : DaemonScreenEvent
}
