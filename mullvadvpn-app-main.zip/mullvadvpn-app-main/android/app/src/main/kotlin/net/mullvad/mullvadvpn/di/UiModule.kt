package net.mullvad.mullvadvpn.di

import android.content.ComponentName
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.MainScope
import net.mullvad.mullvadvpn.BuildConfig
import net.mullvad.mullvadvpn.app.MainActivity
import net.mullvad.mullvadvpn.app.MullvadAppViewModel
import net.mullvad.mullvadvpn.feature.account.impl.AccountViewModel
import net.mullvad.mullvadvpn.feature.addtime.impl.AddTimeViewModel
import net.mullvad.mullvadvpn.feature.anticensorship.impl.AntiCensorshipSettingsViewModel
import net.mullvad.mullvadvpn.feature.anticensorship.impl.customport.CustomPortDialogViewModel
import net.mullvad.mullvadvpn.feature.anticensorship.impl.selectport.SelectPortViewModel
import net.mullvad.mullvadvpn.feature.apiaccess.impl.screen.delete.DeleteApiAccessMethodConfirmationViewModel
import net.mullvad.mullvadvpn.feature.apiaccess.impl.screen.detail.ApiAccessMethodDetailsViewModel
import net.mullvad.mullvadvpn.feature.apiaccess.impl.screen.edit.EditApiAccessMethodViewModel
import net.mullvad.mullvadvpn.feature.apiaccess.impl.screen.list.ApiAccessListViewModel
import net.mullvad.mullvadvpn.feature.apiaccess.impl.screen.save.SaveApiAccessMethodViewModel
import net.mullvad.mullvadvpn.feature.appicon.impl.AppIconViewModel
import net.mullvad.mullvadvpn.feature.appinfo.impl.AppInfoViewModel
import net.mullvad.mullvadvpn.feature.appinfo.impl.changelog.ChangelogViewModel
import net.mullvad.mullvadvpn.feature.applisting.api.ResolveAppListingUseCase
import net.mullvad.mullvadvpn.feature.applisting.impl.AndroidInstallSourceProvider
import net.mullvad.mullvadvpn.feature.applisting.impl.InstallSourceProvider
import net.mullvad.mullvadvpn.feature.applisting.impl.ResolveAppListingUseCaseImpl
import net.mullvad.mullvadvpn.feature.autoconnect.impl.AutoConnectAndLockdownModeViewModel
import net.mullvad.mullvadvpn.feature.customlist.impl.screen.create.CreateCustomListDialogViewModel
import net.mullvad.mullvadvpn.feature.customlist.impl.screen.delete.DeleteCustomListConfirmationViewModel
import net.mullvad.mullvadvpn.feature.customlist.impl.screen.editlist.EditCustomListViewModel
import net.mullvad.mullvadvpn.feature.customlist.impl.screen.editlocations.CustomListLocationsViewModel
import net.mullvad.mullvadvpn.feature.customlist.impl.screen.editname.EditCustomListNameDialogViewModel
import net.mullvad.mullvadvpn.feature.customlist.impl.screen.lists.CustomListsViewModel
import net.mullvad.mullvadvpn.feature.daita.impl.DaitaViewModel
import net.mullvad.mullvadvpn.feature.deleteaccount.impl.deleteaccountconfirmation.DeleteAccountConfirmationViewModel
import net.mullvad.mullvadvpn.feature.dns.impl.CustomDnsDialogViewModel
import net.mullvad.mullvadvpn.feature.dns.impl.DnsSettingsViewModel
import net.mullvad.mullvadvpn.feature.filter.impl.FilterViewModel
import net.mullvad.mullvadvpn.feature.home.impl.connect.ConnectViewModel
import net.mullvad.mullvadvpn.feature.home.impl.connect.HasShowNotificationPromptRepository
import net.mullvad.mullvadvpn.feature.home.impl.connect.notificationbanner.InAppNotificationController
import net.mullvad.mullvadvpn.feature.home.impl.devicerevoked.DeviceRevokedViewModel
import net.mullvad.mullvadvpn.feature.home.impl.outoftime.OutOfTimeViewModel
import net.mullvad.mullvadvpn.feature.home.impl.welcome.WelcomeViewModel
import net.mullvad.mullvadvpn.feature.language.impl.LanguageViewModel
import net.mullvad.mullvadvpn.feature.lansharing.impl.LocalNetworkSharingViewModel
import net.mullvad.mullvadvpn.feature.location.api.LocationBottomSheetState
import net.mullvad.mullvadvpn.feature.location.impl.RelayListScrollConnection
import net.mullvad.mullvadvpn.feature.location.impl.SelectLocationViewModel
import net.mullvad.mullvadvpn.feature.location.impl.bottomsheet.LocationBottomSheetViewModel
import net.mullvad.mullvadvpn.feature.location.impl.list.SelectLocationListViewModel
import net.mullvad.mullvadvpn.feature.location.impl.search.SearchLocationViewModel
import net.mullvad.mullvadvpn.feature.login.impl.LoginViewModel
import net.mullvad.mullvadvpn.feature.login.impl.apiunreachable.ApiUnreachableViewModel
import net.mullvad.mullvadvpn.feature.login.impl.devicelist.DeviceListViewModel
import net.mullvad.mullvadvpn.feature.managedevices.impl.ManageDevicesViewModel
import net.mullvad.mullvadvpn.feature.multihop.impl.MultihopViewModel
import net.mullvad.mullvadvpn.feature.multihopmigration.impl.MultihopMigrationViewModel
import net.mullvad.mullvadvpn.feature.notification.impl.NotificationSettingsViewModel
import net.mullvad.mullvadvpn.feature.problemreport.impl.ReportProblemViewModel
import net.mullvad.mullvadvpn.feature.problemreport.impl.viewlogs.ViewLogsViewModel
import net.mullvad.mullvadvpn.feature.redeemvoucher.impl.VoucherDialogViewModel
import net.mullvad.mullvadvpn.feature.serveripoverride.impl.ServerIpOverridesViewModel
import net.mullvad.mullvadvpn.feature.serveripoverride.impl.reset.ResetServerIpOverridesConfirmationViewModel
import net.mullvad.mullvadvpn.feature.settings.impl.SettingsViewModel
import net.mullvad.mullvadvpn.feature.splittunneling.impl.SplitTunnelingViewModel
import net.mullvad.mullvadvpn.feature.splittunneling.impl.applist.ApplicationsProvider
import net.mullvad.mullvadvpn.feature.splittunneling.impl.applist.SplitTunnelingUseCase
import net.mullvad.mullvadvpn.feature.splittunneling.impl.search.SearchSplitTunnelingViewModel
import net.mullvad.mullvadvpn.feature.vpnsettings.impl.VpnSettingsViewModel
import net.mullvad.mullvadvpn.feature.vpnsettings.impl.mtu.MtuDialogViewModel
import net.mullvad.mullvadvpn.lib.common.constant.BillingTypes
import net.mullvad.mullvadvpn.lib.model.PackageName
import net.mullvad.mullvadvpn.lib.model.RelayListType
import net.mullvad.mullvadvpn.lib.payment.PaymentProvider
import net.mullvad.mullvadvpn.lib.repository.ApiAccessRepository
import net.mullvad.mullvadvpn.lib.repository.AppVersionInfoRepository
import net.mullvad.mullvadvpn.lib.repository.AutoStartAndConnectOnBootRepository
import net.mullvad.mullvadvpn.lib.repository.ChangelogDataProvider
import net.mullvad.mullvadvpn.lib.repository.ChangelogRepository
import net.mullvad.mullvadvpn.lib.repository.CustomListsRepository
import net.mullvad.mullvadvpn.lib.repository.EmptyPaymentUseCase
import net.mullvad.mullvadvpn.lib.repository.MultihopMigrationRepository
import net.mullvad.mullvadvpn.lib.repository.NewDeviceRepository
import net.mullvad.mullvadvpn.lib.repository.PaymentLogic
import net.mullvad.mullvadvpn.lib.repository.PlayPaymentLogic
import net.mullvad.mullvadvpn.lib.repository.ProblemReportRepository
import net.mullvad.mullvadvpn.lib.repository.RelayListFilterRepository
import net.mullvad.mullvadvpn.lib.repository.RelayListRepository
import net.mullvad.mullvadvpn.lib.repository.RelayOverridesRepository
import net.mullvad.mullvadvpn.lib.repository.SettingsRepository
import net.mullvad.mullvadvpn.lib.repository.SplashCompleteRepository
import net.mullvad.mullvadvpn.lib.repository.SplitTunnelingRepository
import net.mullvad.mullvadvpn.lib.repository.VoucherRepository
import net.mullvad.mullvadvpn.lib.repository.WireguardConstraintsRepository
import net.mullvad.mullvadvpn.lib.usecase.ConnectionPathUseCase
import net.mullvad.mullvadvpn.lib.usecase.DeleteCustomDnsUseCase
import net.mullvad.mullvadvpn.lib.usecase.FilterChipUseCase
import net.mullvad.mullvadvpn.lib.usecase.FilteredRelayListUseCase
import net.mullvad.mullvadvpn.lib.usecase.HopSelectionUseCase
import net.mullvad.mullvadvpn.lib.usecase.InternetAvailableUseCase
import net.mullvad.mullvadvpn.lib.usecase.LastKnownLocationUseCase
import net.mullvad.mullvadvpn.lib.usecase.ModifyAndEnableMultihopUseCase
import net.mullvad.mullvadvpn.lib.usecase.ModifyMultihopUseCase
import net.mullvad.mullvadvpn.lib.usecase.MultihopGuideMigrationHintUseCase
import net.mullvad.mullvadvpn.lib.usecase.MultihopInEffectUseCase
import net.mullvad.mullvadvpn.lib.usecase.OutOfTimeUseCase
import net.mullvad.mullvadvpn.lib.usecase.ProviderToOwnershipsUseCase
import net.mullvad.mullvadvpn.lib.usecase.RecentsUseCase
import net.mullvad.mullvadvpn.lib.usecase.RelayItemCanBeSelectedUseCase
import net.mullvad.mullvadvpn.lib.usecase.SelectAndEnableMultihopUseCase
import net.mullvad.mullvadvpn.lib.usecase.SelectSinglehopUseCase
import net.mullvad.mullvadvpn.lib.usecase.SelectedLocationTitleUseCase
import net.mullvad.mullvadvpn.lib.usecase.SelectedLocationUseCase
import net.mullvad.mullvadvpn.lib.usecase.SupportEmailUseCase
import net.mullvad.mullvadvpn.lib.usecase.SystemVpnSettingsAvailableUseCase
import net.mullvad.mullvadvpn.lib.usecase.customlists.CustomListActionUseCase
import net.mullvad.mullvadvpn.lib.usecase.customlists.CustomListRelayItemsUseCase
import net.mullvad.mullvadvpn.lib.usecase.customlists.CustomListsRelayItemUseCase
import net.mullvad.mullvadvpn.lib.usecase.customlists.FilterCustomListsRelayItemUseCase
import net.mullvad.mullvadvpn.lib.usecase.inappnotification.AccountExpiryInAppNotificationUseCase
import net.mullvad.mullvadvpn.lib.usecase.inappnotification.Android16UpdateWarningUseCase
import net.mullvad.mullvadvpn.lib.usecase.inappnotification.InAppNotificationUseCase
import net.mullvad.mullvadvpn.lib.usecase.inappnotification.MultihopMigrationNotificationUseCase
import net.mullvad.mullvadvpn.lib.usecase.inappnotification.NewChangelogNotificationUseCase
import net.mullvad.mullvadvpn.lib.usecase.inappnotification.NewDeviceNotificationUseCase
import net.mullvad.mullvadvpn.lib.usecase.inappnotification.TunnelStateNotificationUseCase
import net.mullvad.mullvadvpn.lib.usecase.inappnotification.VersionNotificationUseCase
import net.mullvad.mullvadvpn.receiver.AutoStartVpnBootCompletedReceiver
import net.mullvad.mullvadvpn.screen.splash.SplashViewModel
import net.mullvad.mullvadvpn.serviceconnection.ServiceConnectionManager
import org.apache.commons.validator.routines.InetAddressValidator
import org.koin.android.ext.koin.androidContext
import org.koin.core.module.dsl.viewModel
import org.koin.core.qualifier.named
import org.koin.dsl.bind
import org.koin.dsl.module

val uiModule = module {
    single<ComponentName>(named(BOOT_COMPLETED_RECEIVER_COMPONENT_NAME)) {
        ComponentName(androidContext(), AutoStartVpnBootCompletedReceiver::class.java)
    }

    single<PackageName> { PackageName(androidContext().packageName) }
    single<InstallSourceProvider> { AndroidInstallSourceProvider(androidContext()) }
    single<ResolveAppListingUseCase> {
        ResolveAppListingUseCaseImpl(
            resources = androidContext().resources,
            packageName = get(),
            isPlayBuild = IS_PLAY_BUILD,
            installSourceProvider = get(),
        )
    }
    single { ApplicationsProvider(get(), get()) }
    scope<MainActivity> { scoped { ServiceConnectionManager(androidContext()) } }
    single { InetAddressValidator.getInstance() }
    single { androidContext().assets }
    single { androidContext().contentResolver }

    single { ChangelogRepository(get(), get(), get()) }
    single { SettingsRepository(get()) }
    single {
        ProblemReportRepository(
            context = androidContext(),
            apiEndpointOverride = getOrNull(),
            apiEndpointFromIntentHolder = get(),
            kermitFileLogDirName = KERMIT_FILE_LOG_DIR_NAME,
            accountRepository = get(),
            paymentLogic = get(),
        )
    }
    single { RelayOverridesRepository(get()) }
    single { CustomListsRepository(get(), get()) }
    single { RelayListRepository(get(), get()) }
    single { RelayListFilterRepository(get()) }
    single { VoucherRepository(get(), get()) }
    single { SplitTunnelingRepository(get()) }
    single { SplitTunnelingUseCase(get(), get(), get(), Dispatchers.IO) }
    single { ApiAccessRepository(get()) }
    single { NewDeviceRepository() }
    single { SplashCompleteRepository() }
    single {
        AutoStartAndConnectOnBootRepository(
            get(),
            get(named(BOOT_COMPLETED_RECEIVER_COMPONENT_NAME)),
        )
    }
    single { WireguardConstraintsRepository(get()) }
    single { MultihopMigrationRepository(managementService = get()) }
    single { HasShowNotificationPromptRepository() }

    single { AccountExpiryInAppNotificationUseCase(get()) } bind InAppNotificationUseCase::class
    single { TunnelStateNotificationUseCase(get(), get(), get()) } bind
        InAppNotificationUseCase::class
    single {
        VersionNotificationUseCase(get(), BuildConfig.ENABLE_IN_APP_VERSION_NOTIFICATIONS)
    } bind InAppNotificationUseCase::class
    single { NewDeviceNotificationUseCase(get(), get()) } bind InAppNotificationUseCase::class
    single { NewChangelogNotificationUseCase(get()) } bind InAppNotificationUseCase::class
    if (Build.VERSION.SDK_INT == Build.VERSION_CODES.BAKLAVA) {
        single { Android16UpdateWarningUseCase(get(), get()) } bind InAppNotificationUseCase::class
    }
    single {
        MultihopMigrationNotificationUseCase(
            multihopMigrationRepository = get(),
            connectionProxy = get(),
            userPreferencesRepository = get(),
        )
    } bind InAppNotificationUseCase::class

    single { OutOfTimeUseCase(get(), get()) }
    single { InternetAvailableUseCase(get()) }
    single { SystemVpnSettingsAvailableUseCase(androidContext()) }
    single { CustomListActionUseCase(get(), get()) }
    single { SelectedLocationTitleUseCase(get(), get()) }
    single { ProviderToOwnershipsUseCase(get()) }
    single { FilterCustomListsRelayItemUseCase(get(), get()) }
    single { CustomListsRelayItemUseCase(get(), get()) }
    single { CustomListRelayItemsUseCase(get(), get()) }
    single { FilteredRelayListUseCase(get(), get(), get()) }
    single { LastKnownLocationUseCase(get()) }
    single {
        MultihopInEffectUseCase(connectionProxy = get(), wireguardConstraintsRepository = get())
    }
    single {
        SelectedLocationUseCase(
            relayListRepository = get(),
            wireguardConstraintsRepository = get(),
            multihopInEffectUseCase = get(),
        )
    }
    single {
        FilterChipUseCase(
            relayListFilterRepository = get(),
            providerToOwnershipsUseCase = get(),
            settingsRepository = get(),
            multihopInEffectUseCase = get(),
            relayListRepository = get(),
        )
    }
    single { DeleteCustomDnsUseCase(get()) }
    single { RecentsUseCase(get(), get(), get()) }
    single { SelectSinglehopUseCase(relayListRepository = get()) }
    single {
        ModifyMultihopUseCase(
            relayListRepository = get(),
            settingsRepository = get(),
            customListsRepository = get(),
            wireguardConstraintsRepository = get(),
        )
    }
    single {
        SupportEmailUseCase(
            context = androidContext(),
            problemReportRepository = get(),
            buildVersion = get(),
        )
    }
    single {
        HopSelectionUseCase(
            customListRelayItemUseCase = get(),
            relayListRepository = get(),
            settingsRepository = get(),
            multihopInEffectUseCase = get(),
        )
    }
    single {
        SelectAndEnableMultihopUseCase(relayListRepository = get(), settingsRepository = get())
    }
    single {
        RelayItemCanBeSelectedUseCase(
            filteredRelayListUseCase = get(),
            hopSelectionUseCase = get(),
            settingsRepository = get(),
            relayListRepository = get(),
        )
    }
    single {
        ModifyAndEnableMultihopUseCase(
            relayListRepository = get(),
            settingsRepository = get(),
            customListsRepository = get(),
            wireguardConstraintsRepository = get(),
        )
    }
    single {
        MultihopGuideMigrationHintUseCase(
            migrationRepository = get(),
            userPreferencesRepository = get(),
        )
    }

    single { ConnectionPathUseCase(get(), get(), get()) }
    single { InAppNotificationController(getAll(), MainScope()) }

    single { ChangelogDataProvider(get()) }

    // Will be resolved using from either of the two PaymentModule.kt classes.
    single { PaymentProvider(get()) }

    single<PaymentLogic> {
        val paymentRepository = get<PaymentProvider>().paymentRepository
        if (paymentRepository != null) {
            PlayPaymentLogic(paymentRepository = paymentRepository)
        } else {
            EmptyPaymentUseCase()
        }
    }

    single { AppVersionInfoRepository(get(), get()) }

    single { RelayListScrollConnection() }

    // View models
    viewModel { AccountViewModel(get(), get(), get()) }
    viewModel { DeleteAccountConfirmationViewModel(get(), get()) }
    viewModel { params -> ChangelogViewModel(navArgs = params.get(), get(), get()) }
    viewModel {
        AppInfoViewModel(
            appVersionInfoRepository = get(),
            isPlayBuild = IS_PLAY_BUILD,
            resolveAppListing = get(),
            multihopMigrationRepository = get(),
            multihopGuideMigrationHintUseCase = get(),
        )
    }
    viewModel {
        ConnectViewModel(
            accountRepository = get(),
            deviceRepository = get(),
            relayListRepository = get(),
            changelogRepository = get(),
            inAppNotificationController = get(),
            newDeviceRepository = get(),
            userPreferencesRepository = get(),
            selectedLocationTitleUseCase = get(),
            outOfTimeUseCase = get(),
            paymentUseCase = get(),
            connectionProxy = get(),
            lastKnownLocationUseCase = get(),
            systemVpnSettingsUseCase = get(),
            isPlayBuild = IS_PLAY_BUILD,
            resolveAppListing = get(),
            connectionPath = get(),
            multihopGuideMigrationHintUseCase = get(),
            hasShownNotificationPromptRepository = get(),
        )
    }
    viewModel { params -> DeviceListViewModel(accountNumber = params.get(), get()) }
    viewModel { params ->
        ManageDevicesViewModel(accountNumber = params.get(), get(), Dispatchers.IO)
    }
    viewModel { DeviceRevokedViewModel(get(), get(), get(), get()) }
    viewModel { params -> MtuDialogViewModel(navArgs = params.get(), get()) }
    viewModel { params -> CustomDnsDialogViewModel(navArgs = params.get(), get(), get(), get()) }
    viewModel { params -> CustomPortDialogViewModel(navArgs = params.get()) }
    viewModel {
        LoginViewModel(
            accountRepository = get(),
            newDeviceRepository = get(),
            internetAvailableUseCase = get(),
            scheduleNotificationAlarmUseCase = get(),
            accountExpiryNotificationProvider = get(),
            ioDispatcher = Dispatchers.IO,
        )
    }
    viewModel {
        SelectLocationViewModel(
            relayListFilterRepository = get(),
            customListActionUseCase = get(),
            relayListRepository = get(),
            wireguardConstraintsRepository = get(),
            filterChipUseCase = get(),
            settingsRepository = get(),
            selectSingleUseCase = get(),
            modifyMultihopUseCase = get(),
            relayListScrollConnection = get(),
            connectionProxy = get(),
            multihopInEffectUseCase = get(),
            hopSelectionUseCase = get(),
            lastKnownLocationUseCase = get(),
        )
    }
    viewModel {
        SettingsViewModel(
            deviceRepository = get(),
            appVersionInfoRepository = get(),
            wireguardConstraintsRepository = get(),
            settingsRepository = get(),
            multihopGuideMigrationHintUseCase = get(),
            connectionProxy = get(),
            isPlayBuild = IS_PLAY_BUILD,
        )
    }
    viewModel { SplashViewModel(get(), get(), get()) }
    viewModel { VoucherDialogViewModel(get(), get()) }
    viewModel { params -> VpnSettingsViewModel(navArgs = params.get(), get(), get(), get(), get()) }
    viewModel { params -> AntiCensorshipSettingsViewModel(isModal = params.get(), get()) }
    viewModel { params -> LocalNetworkSharingViewModel(isModal = params.get(), get()) }
    viewModel { params ->
        WelcomeViewModel(
            accountRepository = get(),
            deviceRepository = get(),
            paymentUseCase = get(),
            connectionProxy = get(),
            activityLifecycle = params.get(),
            isPlayBuild = IS_PLAY_BUILD,
        )
    }
    viewModel {
        ReportProblemViewModel(
            mullvadProblemReporter = get(),
            problemReportRepository = get(),
            accountRepository = get(),
            isPlayBuild = IS_PLAY_BUILD,
        )
    }
    viewModel { ViewLogsViewModel(get()) }
    viewModel { params ->
        OutOfTimeViewModel(
            accountRepository = get(),
            deviceRepository = get(),
            paymentUseCase = get(),
            outOfTimeUseCase = get(),
            connectionProxy = get(),
            activityLifecycle = params.get(),
            isPlayBuild = IS_PLAY_BUILD,
        )
    }
    viewModel { params ->
        FilterViewModel(
            filterTarget = params.get(),
            providerToOwnershipsUseCase = get(),
            relayListFilterRepository = get(),
        )
    }
    viewModel { params ->
        CreateCustomListDialogViewModel(locationCode = params.getOrNull(), get())
    }
    viewModel { params ->
        CustomListLocationsViewModel(navArgs = params.get(), get(), get(), get())
    }
    viewModel { params -> EditCustomListViewModel(customListId = params.get(), get()) }
    viewModel { params -> EditCustomListNameDialogViewModel(navArgs = params.get(), get()) }
    viewModel { CustomListsViewModel(get(), get()) }
    viewModel { params -> DeleteCustomListConfirmationViewModel(navArgs = params.get(), get()) }
    viewModel { params -> ServerIpOverridesViewModel(navArgs = params.get(), get(), get()) }
    viewModel { ResetServerIpOverridesConfirmationViewModel(get()) }
    viewModel { ApiAccessListViewModel(get()) }
    viewModel { params ->
        EditApiAccessMethodViewModel(apiAccessMethodId = params.getOrNull(), get(), get())
    }
    viewModel { params -> SaveApiAccessMethodViewModel(navArgs = params.get(), get()) }
    viewModel { params -> ApiAccessMethodDetailsViewModel(apiAccessMethodId = params.get(), get()) }
    viewModel { params ->
        DeleteApiAccessMethodConfirmationViewModel(apiAccessMethodId = params.get(), get())
    }
    viewModel { params -> SelectPortViewModel(navArgs = params.get(), get(), get(), get()) }
    viewModel { params ->
        MultihopViewModel(
            isModal = params.get(),
            wireguardConstraintsRepository = get(),
            multihopInEffectUseCase = get(),
        )
    }
    viewModel { NotificationSettingsViewModel(get()) }
    viewModel { params ->
        SearchLocationViewModel(
            relayListType = params.get(),
            customListActionUseCase = get(),
            relayListFilterRepository = get(),
            filterChipUseCase = get(),
            selectSinglehopUseCase = get(),
            modifyMultihopUseCase = get(),
            settingsRepository = get(),
            filteredRelayListUseCase = get(),
            filteredCustomListRelayItemsUseCase = get(),
            selectedLocationUseCase = get(),
            customListsRelayItemUseCase = get(),
            connectionProxy = get(),
        )
    }
    viewModel { (relayListType: RelayListType) ->
        SelectLocationListViewModel(
            relayListType = relayListType,
            filteredRelayListUseCase = get(),
            filteredCustomListRelayItemsUseCase = get(),
            selectedLocationUseCase = get(),
            wireguardConstraintsRepository = get(),
            relayListRepository = get(),
            recentsUseCase = get(),
            settingsRepository = get(),
            connectionProxy = get(),
            relayListScrollConnection = get(),
        )
    }
    viewModel { params -> DaitaViewModel(isModal = params.get(), get()) }
    viewModel {
        AddTimeViewModel(
            paymentUseCase = get(),
            accountRepository = get(),
            connectionProxy = get(),
            isPlayBuild = IS_PLAY_BUILD,
        )
    }
    viewModel { params ->
        ApiUnreachableViewModel(
            navArgs = params.get(),
            apiAccessRepository = get(),
            supportEmailUseCase = get(),
        )
    }
    viewModel { (locationBottomSheetState: LocationBottomSheetState) ->
        LocationBottomSheetViewModel(
            locationBottomSheetState = locationBottomSheetState,
            customListActionUseCase = get(),
            canBeSelectedUseCase = get(),
            customListsRelayItemUseCase = get(),
            selectedLocationUseCase = get(),
            modifyMultihopUseCase = get(),
            wireguardConstraintsRepository = get(),
            selectAndEnableMultihopUseCase = get(),
            hopSelectionUseCase = get(),
            modifyAndEnableMultihopUseCase = get(),
            customListsRepository = get(),
            multihopInEffectUseCase = get(),
            ioDispatcher = Dispatchers.IO,
        )
    }
    viewModel { AppIconViewModel(get()) }
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        viewModel { LanguageViewModel(get()) }
    }
    viewModel { AutoConnectAndLockdownModeViewModel(isPlayBuild = IS_PLAY_BUILD) }
    viewModel { params ->
        SplitTunnelingViewModel(isModal = params.get(), get(), get(), get(), Dispatchers.IO)
    }
    viewModel { SearchSplitTunnelingViewModel(get(), get(), Dispatchers.IO) }
    viewModel { params ->
        DnsSettingsViewModel(
            isModal = params.get(),
            settingsRepository = get(),
            dispatcher = Dispatchers.IO,
        )
    }
    viewModel { params ->
        MultihopMigrationViewModel(
            navArgs = params.get(),
            wireguardConstraintsRepository = get(),
            userPreferencesRepository = get(),
        )
    }

    viewModel { params ->
        MullvadAppViewModel(
            connectionProxy = get(),
            managementService = get(),
            activityLifecycle = params.get(),
        )
    }
}

const val APP_PREFERENCES_NAME = "${BuildConfig.APPLICATION_ID}.app_preferences"
const val KERMIT_FILE_LOG_DIR_NAME = "android_app_logs"

private const val BOOT_COMPLETED_RECEIVER_COMPONENT_NAME = "BOOT_COMPLETED_RECEIVER_COMPONENT_NAME"
private const val IS_PLAY_BUILD = BuildConfig.FLAVOR_billing == BillingTypes.PLAY
