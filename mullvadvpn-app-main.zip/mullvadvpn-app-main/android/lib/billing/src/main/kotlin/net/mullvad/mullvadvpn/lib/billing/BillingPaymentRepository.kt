package net.mullvad.mullvadvpn.lib.billing

import android.app.Activity
import arrow.core.Either
import arrow.core.flatMap
import arrow.core.left
import arrow.core.raise.either
import arrow.core.raise.ensure
import arrow.core.right
import co.touchlab.kermit.Logger
import com.android.billingclient.api.BillingClient.BillingResponseCode
import com.android.billingclient.api.Purchase
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.flow
import net.mullvad.mullvadvpn.lib.billing.extension.getProductDetails
import net.mullvad.mullvadvpn.lib.billing.extension.nonPendingPurchases
import net.mullvad.mullvadvpn.lib.billing.extension.responseCode
import net.mullvad.mullvadvpn.lib.billing.extension.toBillingException
import net.mullvad.mullvadvpn.lib.billing.extension.toPaymentAvailability
import net.mullvad.mullvadvpn.lib.billing.extension.toPaymentStatus
import net.mullvad.mullvadvpn.lib.billing.extension.toPurchaseResult
import net.mullvad.mullvadvpn.lib.billing.extension.toPurchaseResultError
import net.mullvad.mullvadvpn.lib.billing.extension.toPurchaseVerificationError
import net.mullvad.mullvadvpn.lib.billing.model.BillingException
import net.mullvad.mullvadvpn.lib.billing.model.PurchaseEvent
import net.mullvad.mullvadvpn.lib.model.PlayExternalObfuscatedAccountId
import net.mullvad.mullvadvpn.lib.model.PlayPurchase
import net.mullvad.mullvadvpn.lib.model.PlayPurchaseInitError
import net.mullvad.mullvadvpn.lib.model.PlayPurchasePaymentToken
import net.mullvad.mullvadvpn.lib.model.PlayPurchaseVerifyError
import net.mullvad.mullvadvpn.lib.payment.PaymentRepository
import net.mullvad.mullvadvpn.lib.payment.ProductIds
import net.mullvad.mullvadvpn.lib.payment.model.PaymentAvailability
import net.mullvad.mullvadvpn.lib.payment.model.ProductId
import net.mullvad.mullvadvpn.lib.payment.model.PurchaseResult
import net.mullvad.mullvadvpn.lib.payment.model.VerificationError
import net.mullvad.mullvadvpn.lib.payment.model.VerificationResult
import net.mullvad.mullvadvpn.lib.userpreferences.UserPreferencesRepository

class BillingPaymentRepository(
    private val billingRepository: BillingRepository,
    private val playPurchaseRepository: PlayPurchaseRepository,
    private val userPreferenceRepository: UserPreferencesRepository,
) : PaymentRepository {

    override fun queryPaymentAvailability(): Flow<PaymentAvailability> = flow {
        emit(PaymentAvailability.Loading)
        val purchases = billingRepository.queryPurchases()

        if (purchases.purchasesList.isEmpty()) {
            // If we have no purchases we can assume that all purchases has been successfully
            // verified, and we can clear the latest successful purchase from the user preferences.
            userPreferenceRepository.clearLatestSuccessfulPurchase()
        }

        val productIdToPaymentStatus =
            purchases.purchasesList
                .filter { it.products.isNotEmpty() }
                .filter {
                    // Filter out purchases that are saved as successful. If they are returned from
                    // the billing library, it means that the play services cache is not updated,
                    // and we should trust the response from the api.
                    it.purchaseToken != userPreferenceRepository.latestSuccessfulPurchase()
                }
                .associate { it.products.first() to it.purchaseState.toPaymentStatus() }
        emit(
            billingRepository
                .queryProducts(listOf(ProductIds.OneMonth, ProductIds.ThreeMonths))
                .toPaymentAvailability(productIdToPaymentStatus),
        )
    }

    @Suppress("LongMethod")
    override fun purchaseProduct(
        productId: ProductId,
        activityProvider: () -> Activity,
    ): Flow<PurchaseResult> = flow {
        emit(PurchaseResult.FetchingProducts)

        val productDetailsResult = billingRepository.queryProducts(listOf(productId.value))

        val productDetails =
            when (productDetailsResult.responseCode()) {
                BillingResponseCode.OK -> {
                    productDetailsResult.getProductDetails(productId.value)
                        ?: run {
                            emit(PurchaseResult.Error.NoProductFound(productId))
                            return@flow
                        }
                }
                else -> {
                    emit(
                        PurchaseResult.Error.FetchProductsError(
                            productId,
                            productDetailsResult.toBillingException(),
                        ),
                    )
                    return@flow
                }
            }

        // Get transaction id
        emit(PurchaseResult.FetchingObfuscationId)
        val obfuscatedId: PlayExternalObfuscatedAccountId =
            initializePurchase()
                .fold(
                    {
                        emit(PurchaseResult.Error.TransactionIdError(productId, null))
                        return@flow
                    },
                    { it },
                )

        val result =
            billingRepository.startPurchaseFlow(
                productDetails = productDetails,
                obfuscatedId = obfuscatedId,
                activityProvider = activityProvider,
            )

        if (result.responseCode == BillingResponseCode.OK) {
            emit(PurchaseResult.BillingFlowStarted)
        } else {
            emit(
                PurchaseResult.Error.BillingError(
                    BillingException(
                        responseCode = result.responseCode,
                        message = result.debugMessage,
                    ),
                ),
            )
            return@flow
        }

        // Wait for a callback from the billing library
        when (val event = billingRepository.purchaseEvents.firstOrNull()) {
            is PurchaseEvent.Error -> emit(event.toPurchaseResult())
            is PurchaseEvent.Completed -> {
                val purchase =
                    event.purchases.firstOrNull()
                        ?: run {
                            emit(PurchaseResult.Error.BillingError(null))
                            return@flow
                        }
                if (purchase.purchaseState == Purchase.PurchaseState.PENDING) {
                    emit(PurchaseResult.Completed.Pending(ProductId(purchase.products.first())))
                } else {
                    emit(PurchaseResult.VerificationStarted)
                    emit(
                        verifyPurchase(purchase)
                            .onRight {
                                // Save the latest successful purchase to the user preferences.
                                // This is used to filter out purchases that are returned from
                                // the billing library, but have already been verified.
                                userPreferenceRepository.setLatestSuccessfulPurchase(
                                    purchase.purchaseToken,
                                )
                            }
                            .fold(
                                { error -> error.toPurchaseResultError() },
                                { verifiedProductId ->
                                    PurchaseResult.Completed.Success(verifiedProductId)
                                },
                            ),
                    )
                }
            }
            PurchaseEvent.UserCanceled -> emit(event.toPurchaseResult())
            else -> emit(PurchaseResult.Error.BillingError(null))
        }
    }

    override suspend fun verifyPurchases(): Either<VerificationError, VerificationResult> = either {
        val purchasesResult = billingRepository.queryPurchases()
        ensure(purchasesResult.responseCode() == BillingResponseCode.OK) {
            VerificationError.BillingError(
                errorCode = purchasesResult.responseCode(),
                purchasesResult.toBillingException(),
            )
        }
        val purchases = purchasesResult.nonPendingPurchases()
        if (purchases.isEmpty()) {
            Logger.d("No purchases to verify")
            return@either VerificationResult.NothingToVerify
        }
        val purchase = purchases.first()
        if (purchase.purchaseToken == userPreferenceRepository.latestSuccessfulPurchase()) {
            Logger.d("Purchase already verified")
            return@either VerificationResult.NothingToVerify
        }
        verifyPurchase(purchase)
            .mapLeft { it.toPurchaseVerificationError() }
            .onRight {
                // Save the latest successful purchase to the user preferences.
                // This is used to filter out purchases that are returned from
                // the billing library, but have already been verified.
                userPreferenceRepository.setLatestSuccessfulPurchase(purchase.purchaseToken)
            }
            .map { productId -> VerificationResult.Success(productId) }
            .bind()
    }

    private suspend fun initializePurchase() =
        playPurchaseRepository.initializePlayPurchase().flatMap {
            if (it.value.isNotEmpty()) {
                it.right()
            } else {
                Logger.e("Obfuscated account id is empty")
                PlayPurchaseInitError.OtherError.left()
            }
        }

    private suspend fun verifyPurchase(
        purchase: Purchase,
    ): Either<PlayPurchaseVerifyError, ProductId> = either {
        ensure(purchase.products.isNotEmpty()) {
            Logger.e("Purchase has no products")
            PlayPurchaseVerifyError.NoProducts
        }
        ensure(purchase.accountIdentifiers?.obfuscatedAccountId != null) {
            Logger.e("Purchase is missing obfuscatedAccountId")
            PlayPurchaseVerifyError.MissingObfuscatedAccountId
        }
        ensure(purchase.purchaseToken.isNotEmpty()) {
            Logger.e("Purchase has no purchase token")
            PlayPurchaseVerifyError.NoPurchaseToken
        }
        playPurchaseRepository
            .verifyPlayPurchase(
                PlayPurchase(
                    productId = purchase.products.first(),
                    purchaseToken = PlayPurchasePaymentToken(purchase.purchaseToken),
                ),
            )
            .also { Logger.i("Purchase verification result $it") }
            .bind()
    }
        .onLeft {
            Logger.e(
                "Failed to verify purchase token ending with ${purchase.purchaseToken.takeLast(2)}",
            )
        }
        .map { ProductId(purchase.products.first()) }
}
