package net.mullvad.mullvadvpn.feature.appinfo.impl

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.tooling.preview.PreviewParameter
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.compose.dropUnlessResumed
import net.mullvad.mullvadvpn.core.Navigator
import net.mullvad.mullvadvpn.feature.appinfo.api.ChangelogNavKey
import net.mullvad.mullvadvpn.feature.multihopmigration.api.MultihopMigrationNavKey
import net.mullvad.mullvadvpn.lib.common.Lc
import net.mullvad.mullvadvpn.lib.common.compose.CollectSideEffectWithLifecycle
import net.mullvad.mullvadvpn.lib.common.compose.dropUnlessResumed
import net.mullvad.mullvadvpn.lib.common.compose.safeOpenUri
import net.mullvad.mullvadvpn.lib.common.compose.showSnackbarImmediately
import net.mullvad.mullvadvpn.lib.common.compose.unlessIsDetail
import net.mullvad.mullvadvpn.lib.model.MultihopMigrationData
import net.mullvad.mullvadvpn.lib.model.SplitFilterMigration
import net.mullvad.mullvadvpn.lib.ui.component.ScaffoldWithSmallTopBar
import net.mullvad.mullvadvpn.lib.ui.component.button.NavigateBackIconButton
import net.mullvad.mullvadvpn.lib.ui.component.drawVerticalScrollbar
import net.mullvad.mullvadvpn.lib.ui.component.listitem.ExternalLinkListItem
import net.mullvad.mullvadvpn.lib.ui.component.listitem.NavigationListItem
import net.mullvad.mullvadvpn.lib.ui.designsystem.MullvadCircularProgressIndicatorLarge
import net.mullvad.mullvadvpn.lib.ui.designsystem.Position
import net.mullvad.mullvadvpn.lib.ui.resource.R
import net.mullvad.mullvadvpn.lib.ui.theme.AppTheme
import net.mullvad.mullvadvpn.lib.ui.theme.Dimens
import net.mullvad.mullvadvpn.lib.ui.theme.color.AlphaScrollbar
import org.koin.androidx.compose.koinViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Preview("Loading|Supported|Unsupported")
@Composable
private fun PreviewAppInfoScreen(
    @PreviewParameter(AppInfoUiStatePreviewParameterProvider::class)
    state: Lc<Unit, AppInfoUiState>,
) {
    AppTheme {
        AppInfo(
            state = state,
            snackbarHostState = SnackbarHostState(),
            onBackClick = {},
            navigateToChangelog = {},
            openAppListing = {},
            navigateToMultihopMigrationGuide = {},
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppInfo(navigator: Navigator) {
    val vm = koinViewModel<AppInfoViewModel>()
    val state by vm.uiState.collectAsStateWithLifecycle()

    val uriHandler = LocalUriHandler.current
    val snackbarHostState = remember { SnackbarHostState() }

    CollectSideEffectWithLifecycle(vm.uiSideEffect) { sideEffect ->
        when (sideEffect) {
            is AppInfoSideEffect.OpenUri -> {
                uriHandler.safeOpenUri(sideEffect.uri.toString()).onLeft {
                    snackbarHostState.showSnackbarImmediately(message = sideEffect.errorMessage)
                }
            }
        }
    }

    AppInfo(
        state = state,
        snackbarHostState = snackbarHostState,
        onBackClick = dropUnlessResumed { navigator.goBack() },
        navigateToChangelog = dropUnlessResumed { navigator.navigate(ChangelogNavKey()) },
        openAppListing = dropUnlessResumed { vm.openAppListing() },
        navigateToMultihopMigrationGuide =
            dropUnlessResumed { splitFilterMigration ->
                navigator.navigate(
                    MultihopMigrationNavKey(
                        multihopMigrationData =
                            MultihopMigrationData(
                                splitFilterMigration = splitFilterMigration,
                                userBlocked = false,
                            ),
                    ),
                )
            },
    )
}

@ExperimentalMaterial3Api
@Composable
fun AppInfo(
    state: Lc<Unit, AppInfoUiState>,
    snackbarHostState: SnackbarHostState,
    onBackClick: () -> Unit,
    navigateToChangelog: () -> Unit,
    openAppListing: () -> Unit,
    navigateToMultihopMigrationGuide: (SplitFilterMigration) -> Unit,
) {
    ScaffoldWithSmallTopBar(
        appBarTitle = stringResource(id = R.string.app_info),
        navigationIcon = {
            unlessIsDetail { NavigateBackIconButton(onNavigateBack = onBackClick) }
        },
        snackbarHostState = snackbarHostState,
    ) { modifier ->
        val scrollState = rememberScrollState()
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier =
                modifier
                    .drawVerticalScrollbar(
                        state = scrollState,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = AlphaScrollbar),
                    )
                    .verticalScroll(state = scrollState)
                    .animateContentSize()
                    .padding(horizontal = Dimens.sideMarginNew),
        ) {
            when (state) {
                is Lc.Loading -> Loading()
                is Lc.Content ->
                    AppInfoContent(
                        state = state.value,
                        navigateToChangelog = navigateToChangelog,
                        openAppListing = openAppListing,
                        navigateToMultihopMigrationGuide = navigateToMultihopMigrationGuide,
                    )
            }
        }
    }
}

@Composable
private fun AppInfoContent(
    state: AppInfoUiState,
    navigateToChangelog: () -> Unit,
    openAppListing: () -> Unit,
    navigateToMultihopMigrationGuide: (SplitFilterMigration) -> Unit,
) {
    Column(modifier = Modifier.padding(bottom = Dimens.smallPadding).animateContentSize()) {
        ChangelogRow(navigateToChangelog)
        if (state.splitFilterMigration != null) {
            HorizontalDivider()
            MultihopMigrationRow(
                showMigrationGuideNotificationDot = state.showMigrationGuideNotificationDot,
                onClick = { navigateToMultihopMigrationGuide(state.splitFilterMigration) },
            )
        }
        HorizontalDivider()
        AppVersionRow(state, openAppListing)
    }
}

@Composable
private fun AppVersionRow(state: AppInfoUiState, openAppListing: () -> Unit) {
    Column {
        ExternalLinkListItem(
            title = stringResource(id = R.string.version),
            subtitle = state.version.currentVersion,
            subTitleTextDirection = TextDirection.Ltr,
            showWarning = !state.version.isSupported,
            position = Position.Bottom,
            onClick = openAppListing,
        )

        if (!state.version.isSupported) {
            Text(
                text = stringResource(id = R.string.unsupported_version_description),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier =
                    Modifier.fillMaxWidth()
                        .padding(
                            start = Dimens.cellStartPadding,
                            end = Dimens.cellStartPadding,
                            top = Dimens.smallPadding,
                            bottom = Dimens.mediumPadding,
                        ),
            )
        }
    }
}

@Composable
private fun ChangelogRow(navigateToChangelog: () -> Unit) {
    NavigationListItem(
        title = stringResource(R.string.changelog_title),
        onClick = navigateToChangelog,
        position = Position.Top,
    )
}

@Composable
private fun MultihopMigrationRow(showMigrationGuideNotificationDot: Boolean, onClick: () -> Unit) {
    NavigationListItem(
        title = stringResource(R.string.migrated_settings),
        onClick = onClick,
        position = Position.Middle,
        showNotificationDot = showMigrationGuideNotificationDot,
    )
}

@Composable
private fun Loading() {
    MullvadCircularProgressIndicatorLarge()
}
