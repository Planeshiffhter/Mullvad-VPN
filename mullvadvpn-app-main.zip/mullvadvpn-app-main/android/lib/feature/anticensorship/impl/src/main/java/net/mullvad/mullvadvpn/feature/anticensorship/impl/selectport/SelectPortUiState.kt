package net.mullvad.mullvadvpn.feature.anticensorship.impl.selectport

import net.mullvad.mullvadvpn.core.NavKey2
import net.mullvad.mullvadvpn.lib.model.Constraint
import net.mullvad.mullvadvpn.lib.model.Port
import net.mullvad.mullvadvpn.lib.model.PortRange
import net.mullvad.mullvadvpn.lib.model.PortType

data class SelectPortUiState(
    val portType: PortType,
    val port: Constraint<Port> = Constraint.Any,
    val customPort: Port? = null,
    val customPortEnabled: Boolean,
    val title: String,
    val allowedPortRanges: List<PortRange> = emptyList(),
    val recommendedPortRanges: List<PortRange> = emptyList(),
    val presetPorts: List<Port> = emptyList(),
    val infoDestination: NavKey2? = null,
) {
    val isCustom = port is Constraint.Only && port.value !in presetPorts
}

data class PortTypeUiState(
    val presetPorts: List<Port>,
    val allowedPortRanges: List<PortRange>,
    val recommendedPortRanges: List<PortRange>,
    val customPortEnabled: Boolean,
    val title: String,
    val infoDestination: NavKey2? = null,
)
