package net.mullvad.mullvadvpn.feature.anticensorship.impl.selectport

import androidx.compose.ui.tooling.preview.PreviewParameterProvider
import net.mullvad.mullvadvpn.feature.anticensorship.impl.UDP2TCP_PRESET_PORTS
import net.mullvad.mullvadvpn.lib.common.Lc
import net.mullvad.mullvadvpn.lib.common.toLc
import net.mullvad.mullvadvpn.lib.model.Constraint
import net.mullvad.mullvadvpn.lib.model.Port
import net.mullvad.mullvadvpn.lib.model.PortType

class SelectPortUiStatePreviewParameterProvider :
    PreviewParameterProvider<Lc<Unit, SelectPortUiState>> {
    override val values: Sequence<Lc<Unit, SelectPortUiState>> =
        sequenceOf(
            SelectPortUiState(
                    portType = PortType.Udp2Tcp,
                    presetPorts = UDP2TCP_PRESET_PORTS,
                    customPortEnabled = false,
                    title = "Select port",
                )
                .toLc(),
            SelectPortUiState(
                    portType = PortType.Lwo,
                    port = Constraint.Only(Port(1)),
                    presetPorts = emptyList(),
                    customPortEnabled = true,
                    title = "Select port",
                )
                .toLc(),
        )
}
