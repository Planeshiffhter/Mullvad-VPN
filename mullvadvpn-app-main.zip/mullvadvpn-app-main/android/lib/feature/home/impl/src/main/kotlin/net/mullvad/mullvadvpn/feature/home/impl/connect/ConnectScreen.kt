package net.mullvad.mullvadvpn.feature.home.impl.connect

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.res.Resources
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.AnimatedVisibilityScope
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.calculateEndPadding
import androidx.compose.foundation.layout.calculateStartPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalResources
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.LocalWindowInfo
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.tooling.preview.PreviewParameter
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.compose.dropUnlessResumed
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import kotlinx.coroutines.launch
import net.mullvad.mullvadvpn.core.LocalResultStore
import net.mullvad.mullvadvpn.core.NavKey2
import net.mullvad.mullvadvpn.core.Navigator
import net.mullvad.mullvadvpn.feature.account.api.AccountNavKey
import net.mullvad.mullvadvpn.feature.anticensorship.api.AntiCensorshipNavKey
import net.mullvad.mullvadvpn.feature.appinfo.api.ChangelogNavKey
import net.mullvad.mullvadvpn.feature.daita.api.DaitaNavKey
import net.mullvad.mullvadvpn.feature.dns.api.DnsSettingsNavKey
import net.mullvad.mullvadvpn.feature.home.api.Android16UpgradeInfoNavKey
import net.mullvad.mullvadvpn.feature.home.api.DeviceRevokedNavKey
import net.mullvad.mullvadvpn.feature.home.api.OutOfTimeNavKey
import net.mullvad.mullvadvpn.feature.home.impl.connect.button.ConnectionButton
import net.mullvad.mullvadvpn.feature.home.impl.connect.button.SwitchLocationButton
import net.mullvad.mullvadvpn.feature.home.impl.connect.connectioninfo.ConnectionDetailPanel
import net.mullvad.mullvadvpn.feature.home.impl.connect.connectioninfo.FeatureIndicatorsPanel
import net.mullvad.mullvadvpn.feature.home.impl.connect.connectioninfo.toInAddress
import net.mullvad.mullvadvpn.feature.home.impl.connect.notificationbanner.NotificationBanner
import net.mullvad.mullvadvpn.feature.lansharing.api.LocalNetworkSharingNavKey
import net.mullvad.mullvadvpn.feature.location.api.SelectLocationNavKey
import net.mullvad.mullvadvpn.feature.location.api.SelectLocationNavResult
import net.mullvad.mullvadvpn.feature.multihop.api.MultihopNavKey
import net.mullvad.mullvadvpn.feature.multihopmigration.api.MultihopMigrationNavKey
import net.mullvad.mullvadvpn.feature.serveripoverride.api.ServerIpOverrideNavKey
import net.mullvad.mullvadvpn.feature.settings.api.SettingsNavKey
import net.mullvad.mullvadvpn.feature.splittunneling.api.SplitTunnelingNavKey
import net.mullvad.mullvadvpn.feature.vpnsettings.api.VpnSettingsNavKey
import net.mullvad.mullvadvpn.lib.common.compose.CONNECTED_ZOOM
import net.mullvad.mullvadvpn.lib.common.compose.CollectSideEffectWithLifecycle
import net.mullvad.mullvadvpn.lib.common.compose.DEFAULT_ZOOM
import net.mullvad.mullvadvpn.lib.common.compose.LocalNavAnimatedVisibilityScope
import net.mullvad.mullvadvpn.lib.common.compose.SECURE_ZOOM_ANIMATION_MILLIS
import net.mullvad.mullvadvpn.lib.common.compose.createOpenAccountPageHook
import net.mullvad.mullvadvpn.lib.common.compose.dropUnlessResumed
import net.mullvad.mullvadvpn.lib.common.compose.fallbackLatLong
import net.mullvad.mullvadvpn.lib.common.compose.isTv
import net.mullvad.mullvadvpn.lib.common.compose.safeOpenUri
import net.mullvad.mullvadvpn.lib.common.compose.showSnackbarImmediately
import net.mullvad.mullvadvpn.lib.common.util.CreateVpnProfile
import net.mullvad.mullvadvpn.lib.common.util.openVpnSettings
import net.mullvad.mullvadvpn.lib.common.util.removeHtmlTags
import net.mullvad.mullvadvpn.lib.map.InteractiveMap
import net.mullvad.mullvadvpn.lib.map.data.GlobeColors
import net.mullvad.mullvadvpn.lib.map.data.Hop
import net.mullvad.mullvadvpn.lib.map.data.LocationMarkerColors
import net.mullvad.mullvadvpn.lib.map.data.Marker
import net.mullvad.mullvadvpn.lib.model.FeatureIndicator
import net.mullvad.mullvadvpn.lib.model.GeoIpLocation
import net.mullvad.mullvadvpn.lib.model.LatLong
import net.mullvad.mullvadvpn.lib.model.Latitude
import net.mullvad.mullvadvpn.lib.model.Longitude
import net.mullvad.mullvadvpn.lib.model.MultihopMigrationData
import net.mullvad.mullvadvpn.lib.model.PrepareError
import net.mullvad.mullvadvpn.lib.model.TunnelState
import net.mullvad.mullvadvpn.lib.tv.NavigationDrawerTv
import net.mullvad.mullvadvpn.lib.ui.component.ExpandChevron
import net.mullvad.mullvadvpn.lib.ui.component.ScaffoldWithTopBarAndDeviceName
import net.mullvad.mullvadvpn.lib.ui.component.drawVerticalScrollbar
import net.mullvad.mullvadvpn.lib.ui.designsystem.MullvadCircularProgressIndicatorLarge
import net.mullvad.mullvadvpn.lib.ui.designsystem.MullvadSnackbar
import net.mullvad.mullvadvpn.lib.ui.icon.MultihopWhenNeeded
import net.mullvad.mullvadvpn.lib.ui.resource.R
import net.mullvad.mullvadvpn.lib.ui.tag.CONNECT_BUTTON_TEST_TAG
import net.mullvad.mullvadvpn.lib.ui.tag.CONNECT_CARD_HEADER_TEST_TAG
import net.mullvad.mullvadvpn.lib.ui.tag.RECONNECT_BUTTON_TEST_TAG
import net.mullvad.mullvadvpn.lib.ui.tag.SELECT_LOCATION_BUTTON_TEST_TAG
import net.mullvad.mullvadvpn.lib.ui.theme.AppTheme
import net.mullvad.mullvadvpn.lib.ui.theme.Dimens
import net.mullvad.mullvadvpn.lib.ui.theme.Shapes
import net.mullvad.mullvadvpn.lib.ui.theme.color.Alpha20
import net.mullvad.mullvadvpn.lib.ui.theme.color.Alpha80
import net.mullvad.mullvadvpn.lib.ui.theme.color.AlphaScrollbar
import net.mullvad.mullvadvpn.lib.ui.theme.color.positive
import net.mullvad.mullvadvpn.lib.ui.util.visible
import org.koin.androidx.compose.koinViewModel

private const val CONNECT_BUTTON_THROTTLE_MILLIS = 1000
private val SCREEN_HEIGHT_THRESHOLD = 700.dp
private const val SHORT_SCREEN_INDICATOR_BIAS = 0.2f
private const val TALL_SCREEN_INDICATOR_BIAS = 0.3f
private const val MIN_HOP_DISTANCE = 20f

@Preview("Initial|Connected|Disconnected|Connecting|Error.VpnPermissionDenied")
@Composable
private fun PreviewAccountScreen(
    @PreviewParameter(ConnectUiStatePreviewParameterProvider::class) state: ConnectUiState,
) {
    AppTheme {
        ConnectScreen(
            state = state,
            snackbarHostState = SnackbarHostState(),
            onDisconnectClick = {},
            onReconnectClick = {},
            onConnectClick = {},
            onCancelClick = {},
            onSwitchLocationClick = {},
            onOpenAppListing = {},
            onManageAccountClick = {},
            onChangelogClick = {},
            onDismissChangelogClick = {},
            onSettingsClick = {},
            onAccountClick = {},
            onDismissNewDeviceClick = {},
            onNavigateToFeature = {},
            onClickShowWireguardPortSettings = {},
            onClickDismissAndroid16UpgradeWarning = {},
            onClickShowAndroid16UpgradeInfo = {},
            onClickShowMultihopMigrationWizard = {},
            onClickDismissMigrateMultihopWarning = {},
        )
    }
}

@OptIn(ExperimentalPermissionsApi::class)
@Suppress("LongMethod", "CyclomaticComplexMethod")
@Composable
fun Connect(navigator: Navigator, animatedVisibilityScope: AnimatedVisibilityScope) {
    val connectViewModel: ConnectViewModel = koinViewModel()

    val state by connectViewModel.uiState.collectAsStateWithLifecycle()

    val context = LocalContext.current

    val snackbarHostState = remember { SnackbarHostState() }

    val createVpnProfile =
        rememberLauncherForActivityResult(CreateVpnProfile()) {
            connectViewModel.createVpnProfileResult(it)
        }

    val notificationPermissionState =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            rememberPermissionState(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            null
        }

    val openAccountPage = LocalUriHandler.current.createOpenAccountPageHook()
    val uriHandler = LocalUriHandler.current
    val resources = LocalResources.current
    CollectSideEffectWithLifecycle(
        connectViewModel.uiSideEffect,
        minActiveState = Lifecycle.State.RESUMED,
    ) { sideEffect ->
        when (sideEffect) {
            is ConnectViewModel.UiSideEffect.OpenAccountManagementPageInBrowser ->
                openAccountPage(sideEffect.token)

            is ConnectViewModel.UiSideEffect.OutOfTime ->
                navigator.navigate(OutOfTimeNavKey, clearBackStack = true)

            ConnectViewModel.UiSideEffect.RevokedDevice ->
                navigator.navigate(DeviceRevokedNavKey, clearBackStack = true)

            is ConnectViewModel.UiSideEffect.NotPrepared ->
                when (sideEffect.prepareError) {
                    is PrepareError.OtherLegacyAlwaysOnVpn ->
                        launch {
                            snackbarHostState.showSnackbarImmediately(
                                message = sideEffect.prepareError.toMessage(resources),
                            )
                        }
                    is PrepareError.OtherAlwaysOnApp ->
                        launch {
                            snackbarHostState.showSnackbarImmediately(
                                message = sideEffect.prepareError.toMessage(resources),
                            )
                        }
                    is PrepareError.NotPrepared -> {
                        try {
                            createVpnProfile.launch(sideEffect.prepareError.prepareIntent)
                        } catch (_: ActivityNotFoundException) {
                            // The app could not find the vpn permission dialog, so instead of
                            // crashing we will tell the user about the issue.
                            snackbarHostState.showSnackbarImmediately(
                                message =
                                    resources.getString(R.string.vpn_dialog_activity_not_found),
                            )
                        }
                    }
                }

            ConnectViewModel.UiSideEffect.ConnectError.Generic ->
                snackbarHostState.showSnackbarImmediately(
                    message = resources.getString(R.string.error_occurred),
                )

            is ConnectViewModel.UiSideEffect.ConnectError.PermissionDenied -> {
                launch {
                    snackbarHostState.showSnackbarImmediately(
                        message =
                            resources.getString(
                                if (sideEffect.systemVpnSettingsAvailable) {
                                    R.string.vpn_permission_denied_error
                                } else {
                                    R.string.vpn_permission_denied_error_no_vpn_settings
                                },
                            ),
                        actionLabel =
                            if (sideEffect.systemVpnSettingsAvailable) {
                                resources.getString(R.string.go_to_vpn_settings)
                            } else {
                                null
                            },
                        withDismissAction = sideEffect.systemVpnSettingsAvailable,
                        onAction = {
                            context.openVpnSettings().onLeft {
                                launch {
                                    snackbarHostState.showSnackbarImmediately(
                                        message =
                                            resources.getString(
                                                R.string.vpn_settings_not_available,
                                            ),
                                    )
                                }
                            }
                        },
                    )
                }
            }

            is ConnectViewModel.UiSideEffect.OpenUri ->
                uriHandler.safeOpenUri(sideEffect.uri.toString()).onLeft {
                    snackbarHostState.showSnackbarImmediately(message = sideEffect.errorMessage)
                }

            ConnectViewModel.UiSideEffect.ShowNotificationPermissionPrompt -> {
                if (
                    notificationPermissionState != null &&
                        !notificationPermissionState.status.isGranted
                ) {
                    notificationPermissionState.launchPermissionRequest()
                    connectViewModel.setHasShownNotificationPrompt()
                }
            }
        }
    }

    LocalResultStore.current.consumeResult<SelectLocationNavResult> { result ->
        if (result.connect) {
            connectViewModel.onConnectClick()
        }
    }

    CompositionLocalProvider(LocalNavAnimatedVisibilityScope provides animatedVisibilityScope) {
        ConnectScreen(
            state = state,
            snackbarHostState = snackbarHostState,
            onDisconnectClick = connectViewModel::onDisconnectClick,
            onReconnectClick = connectViewModel::onReconnectClick,
            onConnectClick = connectViewModel::onConnectClick,
            onCancelClick = connectViewModel::onCancelClick,
            onSwitchLocationClick = dropUnlessResumed { navigator.navigate(SelectLocationNavKey) },
            onOpenAppListing = connectViewModel::openAppListing,
            onManageAccountClick = connectViewModel::onManageAccountClick,
            onChangelogClick =
                dropUnlessResumed { navigator.navigate(ChangelogNavKey(isModal = true)) },
            onDismissChangelogClick = connectViewModel::dismissNewChangelogNotification,
            onSettingsClick =
                dropUnlessResumed {
                    if (navigator.screenIsListDetailTargetWidth) {
                        navigator.navigate(SettingsNavKey, DaitaNavKey())
                    } else {
                        navigator.navigate(SettingsNavKey)
                    }
                },
            onAccountClick = dropUnlessResumed { navigator.navigate(AccountNavKey) },
            onDismissNewDeviceClick = connectViewModel::dismissNewDeviceNotification,
            onNavigateToFeature =
                dropUnlessResumed { feature: FeatureIndicator ->
                    navigator.navigate(feature.navKey())
                },
            onClickShowWireguardPortSettings =
                dropUnlessResumed { navigator.navigate(VpnSettingsNavKey()) },
            onClickDismissAndroid16UpgradeWarning =
                connectViewModel::dismissAndroid16UpgradeWarning,
            onClickShowAndroid16UpgradeInfo =
                dropUnlessResumed { navigator.navigate(Android16UpgradeInfoNavKey) },
            onClickShowMultihopMigrationWizard =
                dropUnlessResumed { multihopMigrationData: MultihopMigrationData ->
                    navigator.navigate(
                        MultihopMigrationNavKey(multihopMigrationData = multihopMigrationData),
                    )
                },
            onClickDismissMigrateMultihopWarning =
                connectViewModel::dismissMultihopMigrationWarning,
        )
    }
}

@OptIn(ExperimentalComposeUiApi::class)
@Composable
@Suppress("LongParameterList")
fun ConnectScreen(
    state: ConnectUiState,
    snackbarHostState: SnackbarHostState = remember { SnackbarHostState() },
    onDisconnectClick: () -> Unit,
    onReconnectClick: () -> Unit,
    onConnectClick: () -> Unit,
    onCancelClick: () -> Unit,
    onSwitchLocationClick: () -> Unit,
    onOpenAppListing: () -> Unit,
    onManageAccountClick: () -> Unit,
    onChangelogClick: () -> Unit,
    onDismissChangelogClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onAccountClick: () -> Unit,
    onDismissNewDeviceClick: () -> Unit,
    onNavigateToFeature: (FeatureIndicator) -> Unit,
    onClickShowWireguardPortSettings: () -> Unit,
    onClickDismissAndroid16UpgradeWarning: () -> Unit,
    onClickShowAndroid16UpgradeInfo: () -> Unit,
    onClickShowMultihopMigrationWizard: (MultihopMigrationData) -> Unit,
    onClickDismissMigrateMultihopWarning: () -> Unit,
) {
    val contentFocusRequester = remember { FocusRequester() }

    val content =
        @Composable { padding: PaddingValues ->
            Content(
                focusRequester = contentFocusRequester,
                paddingValues = padding,
                state = state,
                onDisconnectClick = onDisconnectClick,
                onReconnectClick = onReconnectClick,
                onConnectClick = onConnectClick,
                onCancelClick = onCancelClick,
                onSwitchLocationClick = onSwitchLocationClick,
                onOpenAppListing = onOpenAppListing,
                onManageAccountClick = onManageAccountClick,
                onChangelogClick = onChangelogClick,
                onDismissChangelogClick = onDismissChangelogClick,
                onDismissNewDeviceClick = onDismissNewDeviceClick,
                onNavigateToFeature = onNavigateToFeature,
                onClickShowWireguardPortSettings = onClickShowWireguardPortSettings,
                onClickDismissAndroid16UpgradeWarning = onClickDismissAndroid16UpgradeWarning,
                onClickShowAndroid16UpgradeInfo = onClickShowAndroid16UpgradeInfo,
                onClickShowMultihopMigrationWizard = onClickShowMultihopMigrationWizard,
                onClickDismissMigrateMultihopWarning = onClickDismissMigrateMultihopWarning,
            )
        }

    if (isTv()) {
        Scaffold(
            snackbarHost = {
                SnackbarHost(
                    snackbarHostState,
                    snackbar = { snackbarData ->
                        MullvadSnackbar(snackbarData = snackbarData, actionOnNewLine = true)
                    },
                )
            },
        ) {
            NavigationDrawerTv(
                daysLeftUntilExpiry = state.daysLeftUntilExpiry,
                deviceName = state.deviceName,
                onSettingsClick = onSettingsClick,
                onAccountClick = onAccountClick,
            ) {
                content(it)
            }
        }
        LaunchedEffect(Unit) { contentFocusRequester.requestFocus() }
    } else {
        ScaffoldWithTopBarAndDeviceName(
            topBarColor = state.tunnelState.topBarColor(),
            iconTintColor = state.tunnelState.iconTintColor(),
            onSettingsClicked = onSettingsClick,
            onAccountClicked = onAccountClick,
            deviceName = state.deviceName,
            timeLeft = state.daysLeftUntilExpiry,
            showSettingsNotificationDot = state.showMigrationGuideNotificationDot,
            snackbarHostState = snackbarHostState,
        ) {
            content(it)
        }
    }
}

@Composable
@Suppress("LongParameterList")
private fun Content(
    focusRequester: FocusRequester,
    paddingValues: PaddingValues,
    state: ConnectUiState,
    onDisconnectClick: () -> Unit,
    onReconnectClick: () -> Unit,
    onConnectClick: () -> Unit,
    onCancelClick: () -> Unit,
    onSwitchLocationClick: () -> Unit,
    onOpenAppListing: () -> Unit,
    onManageAccountClick: () -> Unit,
    onChangelogClick: () -> Unit,
    onDismissChangelogClick: () -> Unit,
    onDismissNewDeviceClick: () -> Unit,
    onNavigateToFeature: (FeatureIndicator) -> Unit,
    onClickShowWireguardPortSettings: () -> Unit,
    onClickDismissAndroid16UpgradeWarning: () -> Unit,
    onClickShowAndroid16UpgradeInfo: () -> Unit,
    onClickShowMultihopMigrationWizard: (MultihopMigrationData) -> Unit,
    onClickDismissMigrateMultihopWarning: () -> Unit,
) {
    val screenHeight =
        with(LocalDensity.current) { LocalWindowInfo.current.containerSize.height.toDp() }

    val indicatorPercentOffset =
        if (screenHeight < SCREEN_HEIGHT_THRESHOLD) SHORT_SCREEN_INDICATOR_BIAS
        else TALL_SCREEN_INDICATOR_BIAS

    Box(
        Modifier.padding(
                top = paddingValues.calculateTopPadding(),
                start = paddingValues.calculateStartPadding(LocalLayoutDirection.current),
                end = paddingValues.calculateEndPadding(LocalLayoutDirection.current),
            )
            .fillMaxSize(),
    ) {
        MullvadMap(state, indicatorPercentOffset)

        MullvadCircularProgressIndicatorLarge(
            color = MaterialTheme.colorScheme.onSurface,
            modifier =
                Modifier.layout { measurable, constraints ->
                        val placeable = measurable.measure(constraints)
                        layout(placeable.width, placeable.height) {
                            placeable.placeRelative(
                                x = (constraints.maxWidth * 0.5f - placeable.width / 2).toInt(),
                                y =
                                    (constraints.maxHeight * indicatorPercentOffset -
                                            placeable.height / 2)
                                        .toInt(),
                            )
                        }
                    }
                    .visible(state.showLoading),
        )

        Box(
            modifier =
                Modifier.fillMaxSize().padding(bottom = paddingValues.calculateBottomPadding()),
        ) {
            NotificationBanner(
                modifier = Modifier.align(Alignment.TopCenter),
                notification = state.inAppNotification,
                isPlayBuild = state.isPlayBuild,
                contentFocusRequester = focusRequester,
                openAppListing = onOpenAppListing,
                onClickShowAccount = onManageAccountClick,
                onClickShowChangelog = onChangelogClick,
                onClickShowAndroid16UpgradeInfo = onClickShowAndroid16UpgradeInfo,
                onClickDismissChangelog = onDismissChangelogClick,
                onClickDismissNewDevice = onDismissNewDeviceClick,
                onClickShowWireguardPortSettings = onClickShowWireguardPortSettings,
                onClickDismissAndroid16UpgradeWarning = onClickDismissAndroid16UpgradeWarning,
                onClickShowMultihopMigrationWizard = onClickShowMultihopMigrationWizard,
                onClickDismissMigrateMultihopWarning = onClickDismissMigrateMultihopWarning,
            )
            ConnectionCard(
                state = state,
                modifier = Modifier.align(Alignment.BottomCenter),
                focusRequester = focusRequester,
                isWhenNeededMultihop = state.tunnelState.isWhenNeededMultihopInEffect(),
                onSwitchLocationClick = onSwitchLocationClick,
                onDisconnectClick = onDisconnectClick,
                onReconnectClick = onReconnectClick,
                onCancelClick = onCancelClick,
                onConnectClick = onConnectClick,
                onNavigateToFeature = onNavigateToFeature,
            )
        }
    }
}

@Composable
private fun MullvadMap(state: ConnectUiState, progressIndicatorBias: Float) {

    // Distance to marker when connected/not connected
    val secureZoom =
        animateFloatAsState(
            targetValue =
                if (state.tunnelState is TunnelState.Connected) CONNECTED_ZOOM else DEFAULT_ZOOM,
            animationSpec = tween(SECURE_ZOOM_ANIMATION_MILLIS),
            label = "baseZoom",
        )

    val locationMarker = state.tunnelState.toMarker(state.internetLocation)

    val hops =
        remember(state.hops) {
            state.hops
                .toHops()
                .map { Hop(it.first, it.second) }
                // Ignore hops that are too close
                .filter { it.from.seppDistanceTo(it.to) > MIN_HOP_DISTANCE }
        }

    InteractiveMap(
        currentLocation = state.internetLocation?.toLatLong() ?: fallbackLatLong,
        secureZoom.value,
        progressIndicatorBias,
        markers = listOfNotNull(locationMarker),
        locations = state.locations,
        hops = hops,
        globeColors =
            GlobeColors(
                landColor = MaterialTheme.colorScheme.primary,
                oceanColor = MaterialTheme.colorScheme.surface,
                backgroundColor = MaterialTheme.colorScheme.tertiary,
            ),
    )
}

@Composable
private fun ConnectionCard(
    state: ConnectUiState,
    modifier: Modifier = Modifier,
    focusRequester: FocusRequester,
    isWhenNeededMultihop: Boolean,
    onSwitchLocationClick: () -> Unit,
    onDisconnectClick: () -> Unit,
    onReconnectClick: () -> Unit,
    onCancelClick: () -> Unit,
    onConnectClick: () -> Unit,
    onNavigateToFeature: (FeatureIndicator) -> Unit,
) {
    var expanded by
        rememberSaveable(state.tunnelState is TunnelState.Disconnected) { mutableStateOf(false) }
    val containerColor =
        animateColorAsState(
            if (expanded) MaterialTheme.colorScheme.secondaryContainer
            else MaterialTheme.colorScheme.secondaryContainer.copy(alpha = Alpha80),
            label = "connection_card_color",
        )

    Card(
        modifier =
            modifier.widthIn(max = Dimens.connectionCardMaxWidth).padding(Dimens.mediumPadding),
        Shapes.large,
        colors = CardDefaults.cardColors(containerColor = containerColor.value),
    ) {
        Column(modifier = Modifier.padding(all = Dimens.mediumPadding)) {
            ConnectionCardHeader(
                state = state,
                location = state.internetLocation,
                isWhenNeededMultihop = isWhenNeededMultihop,
                expanded = expanded,
            ) {
                expanded = !expanded
            }

            AnimatedContent(
                state.tunnelState.featureIndicators() to expanded,
                modifier = Modifier.weight(1f, fill = false),
                label = "connection_card_connection_details",
            ) { (featureIndicators, exp) ->
                if (featureIndicators != null) {
                    ConnectionInfo(
                        featureIndicators,
                        state.tunnelState.toConnectionsDetails(),
                        exp,
                        onToggleExpand = { expanded = !exp },
                        onNavigateToFeature = onNavigateToFeature,
                    )
                } else {
                    Spacer(Modifier.height(Dimens.smallSpacer))
                }
            }

            Spacer(Modifier.height(Dimens.mediumPadding))

            ButtonPanel(
                state,
                focusRequester,
                onSwitchLocationClick,
                onDisconnectClick,
                onReconnectClick,
                onCancelClick,
                onConnectClick,
            )
        }
    }
}

@Composable
private fun ConnectionCardHeader(
    state: ConnectUiState,
    location: GeoIpLocation?,
    expanded: Boolean,
    isWhenNeededMultihop: Boolean,
    onToggleExpand: () -> Unit,
) {
    Column(
        modifier =
            Modifier.fillMaxWidth()
                .clickable(
                    enabled = state.tunnelState.isConnectingOrConnected(),
                    onClick = onToggleExpand,
                )
                .testTag(CONNECT_CARD_HEADER_TEST_TAG),
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            ConnectionStatusText(state = state.tunnelState)
            if (state.tunnelState.isConnectingOrConnected()) {
                ExpandChevron(isExpanded = !expanded)
            }
        }

        Text(
            modifier = Modifier.fillMaxWidth().padding(top = Dimens.tinyPadding),
            text = location.asString(),
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )

        AnimatedContent(location?.multihopEntryCountryCity(), label = "via_country_city") {
            if (it != null) {
                Row(
                    modifier = Modifier.padding(bottom = Dimens.tinyPadding),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (isWhenNeededMultihop) {
                        Icon(
                            modifier = Modifier.size(Dimens.smallIconSize),
                            imageVector = MultihopWhenNeeded,
                            contentDescription = null,
                        )
                        Spacer(Modifier.width(Dimens.tinyPadding))
                    }
                    Text(
                        modifier = Modifier.fillMaxWidth(),
                        text = stringResource(R.string.via_country_city, it.country, it.city),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }

        val hostnameText = location.hostnameText()
        AnimatedContent(hostnameText, label = "hostname") {
            if (it != null) {
                Text(
                    modifier = Modifier.fillMaxWidth(),
                    text = it,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

@Composable
private fun GeoIpLocation?.asString(): String {
    val city = this?.city
    return when {
        this == null -> ""
        city.isNullOrBlank() -> country
        else -> stringResource(R.string.country_comma_city, country, city)
    }
}

@Composable
private fun GeoIpLocation?.hostnameText(): String? {
    val entryHostname = this?.entryLocation?.code
    val exitHostname = this?.location?.code
    return when {
        entryHostname != null && exitHostname != null ->
            stringResource(R.string.x_via_x, exitHostname, entryHostname)
        else -> exitHostname
    }
}

private data class MultihopEntryInfo(val country: String, val city: String)

@Suppress("ReturnCount")
private fun GeoIpLocation.multihopEntryCountryCity(): MultihopEntryInfo? {
    val country = entryCountry ?: return null
    val city = entryCity ?: return null
    return MultihopEntryInfo(country, city)
}

@Composable
private fun ConnectionInfo(
    featureIndicators: List<FeatureIndicator>,
    connectionDetails: ConnectionDetails?,
    expanded: Boolean,
    onToggleExpand: () -> Unit,
    onNavigateToFeature: (FeatureIndicator) -> Unit,
) {
    val scrollState = rememberScrollState()
    Column {
        if (expanded) {
            HorizontalDivider(
                Modifier.padding(vertical = Dimens.smallPadding),
                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(Alpha20),
            )
        }
        Column(
            modifier =
                Modifier.fillMaxWidth()
                    .drawVerticalScrollbar(
                        scrollState,
                        color = MaterialTheme.colorScheme.onPrimary.copy(alpha = AlphaScrollbar),
                    )
                    .verticalScroll(scrollState),
        ) {
            FeatureIndicatorsPanel(featureIndicators, expanded, onToggleExpand, onNavigateToFeature)

            AnimatedVisibility(expanded && connectionDetails != null) {
                ConnectionDetailPanel(connectionDetails, enableSelectableText = !isTv())
            }
        }
    }
}

data class ConnectionDetails(
    val inAddress: String,
    val outIpv4Address: String?,
    val outIpv6Address: String?,
)

@Composable
fun TunnelState.toConnectionsDetails(): ConnectionDetails? {
    val endpoint =
        when (this) {
            is TunnelState.Connected -> endpoint
            is TunnelState.Connecting -> endpoint
            else -> null
        }

    if (endpoint == null) return null

    return ConnectionDetails(
        endpoint.toInAddress(),
        location()?.ipv4?.hostAddress,
        location()?.ipv6?.hostAddress,
    )
}

@Composable
private fun ButtonPanel(
    state: ConnectUiState,
    selectButtonFocusRequester: FocusRequester,
    onSwitchLocationClick: () -> Unit,
    onDisconnectClick: () -> Unit,
    onReconnectClick: () -> Unit,
    onCancelClick: () -> Unit,
    onConnectClick: () -> Unit,
) {
    var lastConnectionActionTimestamp by remember { mutableLongStateOf(0L) }

    fun handleThrottledAction(action: () -> Unit) {
        val currentTime = System.currentTimeMillis()
        if ((currentTime - lastConnectionActionTimestamp) > CONNECT_BUTTON_THROTTLE_MILLIS) {
            lastConnectionActionTimestamp = currentTime
            action.invoke()
        }
    }
    Column(modifier = Modifier.padding(top = Dimens.tinyPadding)) {
        SwitchLocationButton(
            text = state.selectedRelayItemTitle ?: stringResource(id = R.string.switch_location),
            onSwitchLocation = onSwitchLocationClick,
            reconnectClick = {
                handleThrottledAction {
                    onReconnectClick()
                    selectButtonFocusRequester.requestFocus()
                }
            },
            isReconnectButtonEnabled =
                state.tunnelState is TunnelState.Connected ||
                    state.tunnelState is TunnelState.Connecting,
            modifier =
                Modifier.testTag(SELECT_LOCATION_BUTTON_TEST_TAG)
                    .focusRequester(selectButtonFocusRequester),
            reconnectButtonTestTag = RECONNECT_BUTTON_TEST_TAG,
        )
        Spacer(Modifier.height(Dimens.buttonSpacing))

        ConnectionButton(
            modifier = Modifier.fillMaxWidth().testTag(CONNECT_BUTTON_TEST_TAG),
            state = state.tunnelState,
            disconnectClick = onDisconnectClick,
            cancelClick = onCancelClick,
            connectClick = { handleThrottledAction(onConnectClick) },
        )
    }
}

@Composable
fun TunnelState.toMarker(location: GeoIpLocation?): Marker? {
    if (location == null) return null
    return when (this) {
        is TunnelState.Connected ->
            Marker(
                location.toLatLong(),
                colors = LocationMarkerColors(centerColor = MaterialTheme.colorScheme.positive),
            )

        is TunnelState.Connecting -> null
        is TunnelState.Disconnected ->
            Marker(
                location.toLatLong(),
                colors = LocationMarkerColors(centerColor = MaterialTheme.colorScheme.error),
            )
        is TunnelState.Disconnecting -> null
        is TunnelState.Error -> null
    }
}

@Composable
fun TunnelState.topBarColor(): Color =
    if (isSecured()) MaterialTheme.colorScheme.positive else MaterialTheme.colorScheme.error

@Composable
fun TunnelState.iconTintColor(): Color =
    if (isSecured()) {
        MaterialTheme.colorScheme.onTertiary
    } else {
        MaterialTheme.colorScheme.onError
    }

fun GeoIpLocation.toLatLong() =
    LatLong(Latitude(latitude.toFloat()), Longitude(longitude.toFloat()))

private fun PrepareError.OtherLegacyAlwaysOnVpn.toMessage(resources: Resources) =
    resources.getString(R.string.legacy_always_on_vpn_error_notification_content)

private fun PrepareError.OtherAlwaysOnApp.toMessage(resources: Resources) =
    resources.getString(R.string.always_on_vpn_error_notification_content, appName).removeHtmlTags()

private fun FeatureIndicator.navKey(): NavKey2 =
    when (this) {
        FeatureIndicator.DAITA -> DaitaNavKey(isModal = true)
        FeatureIndicator.SPLIT_TUNNELING -> SplitTunnelingNavKey(isModal = true)
        FeatureIndicator.MULTIHOP_AUTO,
        FeatureIndicator.MULTIHOP -> MultihopNavKey(selectedFeature = this, isModal = true)

        FeatureIndicator.SERVER_IP_OVERRIDE -> ServerIpOverrideNavKey(isModal = true)

        FeatureIndicator.UDP_2_TCP,
        FeatureIndicator.QUIC,
        FeatureIndicator.WIREGUARD_PORT,
        FeatureIndicator.SHADOWSOCKS,
        FeatureIndicator.LWO -> AntiCensorshipNavKey(selectedFeature = this, isModal = true)

        FeatureIndicator.LAN_SHARING -> LocalNetworkSharingNavKey(isModal = true)

        FeatureIndicator.DNS_CONTENT_BLOCKERS,
        FeatureIndicator.CUSTOM_DNS -> DnsSettingsNavKey(selectedFeature = this, isModal = true)

        FeatureIndicator.QUANTUM_RESISTANCE,
        FeatureIndicator.CUSTOM_MTU -> VpnSettingsNavKey(scrollToFeature = this, isModal = true)
    }
