package net.mullvad.mullvadvpn.feature.home.impl.outoftime

import androidx.compose.ui.test.ExperimentalTestApi
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import de.mannodermaus.junit5.compose.ComposeContext
import io.mockk.MockKAnnotations
import io.mockk.every
import io.mockk.mockk
import io.mockk.verify
import kotlinx.coroutines.flow.MutableStateFlow
import net.mullvad.mullvadvpn.feature.addtime.impl.AddTimeUiState
import net.mullvad.mullvadvpn.feature.addtime.impl.AddTimeViewModel
import net.mullvad.mullvadvpn.lib.common.Lc
import net.mullvad.mullvadvpn.lib.common.toLc
import net.mullvad.mullvadvpn.lib.model.TunnelState
import net.mullvad.mullvadvpn.lib.payment.model.PaymentStatus
import net.mullvad.mullvadvpn.lib.ui.tag.PLAY_PAYMENT_INFO_ICON_TEST_TAG
import net.mullvad.mullvadvpn.screen.test.createEdgeToEdgeComposeExtension
import net.mullvad.mullvadvpn.screen.test.setContentWithTheme
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.RegisterExtension
import org.koin.core.context.loadKoinModules
import org.koin.core.module.dsl.viewModel
import org.koin.dsl.module

@OptIn(ExperimentalTestApi::class)
class OutOfTimeScreenTest {
    @JvmField @RegisterExtension val composeExtension = createEdgeToEdgeComposeExtension()

    private val addTimeViewModel: AddTimeViewModel = mockk(relaxed = true)

    @BeforeEach
    fun setup() {
        MockKAnnotations.init(this)
        loadKoinModules(module { viewModel { addTimeViewModel } })
        every { addTimeViewModel.uiState } returns
            MutableStateFlow<Lc<Unit, AddTimeUiState>>(Lc.Loading(Unit))
    }

    private fun ComposeContext.initScreen(
        state: Lc<Unit, OutOfTimeUiState> = OutOfTimeUiState().toLc(),
        onDisconnectClick: () -> Unit = {},
        onSettingsClick: () -> Unit = {},
        onAccountClick: () -> Unit = {},
        onPlayPaymentInfoClick: (PaymentStatus) -> Unit = {},
        onAddMoreTimeClick: () -> Unit = {},
    ) {

        setContentWithTheme {
            OutOfTimeScreen(
                state = state,
                onDisconnectClick = onDisconnectClick,
                onSettingsClick = onSettingsClick,
                onAccountClick = onAccountClick,
                onPlayPaymentInfoClick = onPlayPaymentInfoClick,
                onAddMoreTimeClick = onAddMoreTimeClick,
            )
        }
    }

    @Test
    fun testDisableSitePayment() = composeExtension.use {
        // Arrange
        initScreen(state = OutOfTimeUiState(showSitePayment = false).toLc())

        // Assert
        onNodeWithText("Either buy credit on our website or redeem a voucher.", substring = true)
            .assertDoesNotExist()
    }

    @Test
    fun testOpenAccountView() = composeExtension.use {
        val mockClickListener: () -> Unit = mockk(relaxed = true)

        // Arrange
        initScreen(
            state = OutOfTimeUiState(showSitePayment = true).toLc(),
            onAccountClick = mockClickListener,
        )

        onNodeWithContentDescription(label = "Account").performClick()

        // Assert
        verify(exactly = 1) { mockClickListener.invoke() }
    }

    @Test
    fun testClickDisconnect() = composeExtension.use {
        // Arrange
        val mockClickListener: () -> Unit = mockk(relaxed = true)
        initScreen(
            state =
                OutOfTimeUiState(
                        tunnelState = TunnelState.Connecting(null, null, emptyList()),
                        showSitePayment = true,
                    )
                    .toLc(),
            onDisconnectClick = mockClickListener,
        )

        // Act
        onNodeWithText("Disconnect").performClick()

        // Assert
        verify(exactly = 1) { mockClickListener.invoke() }
    }

    @Test
    fun testShowPendingPaymentInfoDialog() = composeExtension.use {
        // Arrange
        val mockOnPlayPaymentInfoClick: (PaymentStatus) -> Unit = mockk(relaxed = true)
        initScreen(
            state =
                OutOfTimeUiState(
                        showSitePayment = true,
                        paymentStatus = PaymentStatus.PURCHASED_UNVERIFIED,
                    )
                    .toLc(),
            onPlayPaymentInfoClick = mockOnPlayPaymentInfoClick,
        )

        // Act
        onNodeWithTag(PLAY_PAYMENT_INFO_ICON_TEST_TAG).performClick()
        onNodeWithTag(PLAY_PAYMENT_INFO_ICON_TEST_TAG).assertExists()

        // Assert
        verify(exactly = 1) {
            mockOnPlayPaymentInfoClick.invoke(PaymentStatus.PURCHASED_UNVERIFIED)
        }
    }

    @Test
    fun testShowVerificationInProgress() = composeExtension.use {
        // Arrange
        initScreen(
            state =
                OutOfTimeUiState(showSitePayment = true, paymentStatus = PaymentStatus.PENDING)
                    .toLc(),
        )

        // Assert
        onNodeWithText("Google Play payment pending").assertExists()
    }
}
