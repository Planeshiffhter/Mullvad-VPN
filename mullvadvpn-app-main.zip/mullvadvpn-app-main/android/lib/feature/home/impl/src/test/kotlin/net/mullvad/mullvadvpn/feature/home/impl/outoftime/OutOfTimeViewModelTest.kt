package net.mullvad.mullvadvpn.feature.home.impl.outoftime

import androidx.lifecycle.Lifecycle
import androidx.lifecycle.viewModelScope
import app.cash.turbine.test
import arrow.core.right
import io.mockk.coEvery
import io.mockk.coVerify
import io.mockk.every
import io.mockk.mockk
import io.mockk.unmockkAll
import kotlin.test.assertEquals
import kotlin.test.assertIs
import kotlinx.coroutines.flow.MutableStateFlow
import net.mullvad.mullvadvpn.lib.common.Lc
import net.mullvad.mullvadvpn.lib.common.test.TestCoroutineRule
import net.mullvad.mullvadvpn.lib.common.test.runAndCancelContextTest
import net.mullvad.mullvadvpn.lib.model.AccountData
import net.mullvad.mullvadvpn.lib.model.AccountNumber
import net.mullvad.mullvadvpn.lib.model.Device
import net.mullvad.mullvadvpn.lib.model.DeviceId
import net.mullvad.mullvadvpn.lib.model.DeviceState
import net.mullvad.mullvadvpn.lib.model.DisconnectReason
import net.mullvad.mullvadvpn.lib.model.TunnelState
import net.mullvad.mullvadvpn.lib.model.WebsiteAuthToken
import net.mullvad.mullvadvpn.lib.payment.model.PaymentAvailability
import net.mullvad.mullvadvpn.lib.payment.model.PaymentProduct
import net.mullvad.mullvadvpn.lib.payment.model.PaymentStatus
import net.mullvad.mullvadvpn.lib.payment.model.ProductId
import net.mullvad.mullvadvpn.lib.payment.model.ProductPrice
import net.mullvad.mullvadvpn.lib.payment.model.PurchaseResult
import net.mullvad.mullvadvpn.lib.repository.AccountRepository
import net.mullvad.mullvadvpn.lib.repository.ConnectionProxy
import net.mullvad.mullvadvpn.lib.repository.DeviceRepository
import net.mullvad.mullvadvpn.lib.repository.PaymentLogic
import net.mullvad.mullvadvpn.lib.usecase.OutOfTimeUseCase
import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith

@ExtendWith(TestCoroutineRule::class)
class OutOfTimeViewModelTest {

    private val accountExpiryStateFlow = MutableStateFlow<AccountData?>(null)
    private val accountStateFlow =
        MutableStateFlow<DeviceState?>(DeviceState.LoggedIn(AccountNumber(""), MOCK_DEVICE))
    private val paymentAvailabilityFlow = MutableStateFlow<PaymentAvailability?>(null)
    private val purchaseResultFlow = MutableStateFlow<PurchaseResult?>(null)
    private val outOfTimeFlow = MutableStateFlow(true)

    // Connection Proxy
    private val mockConnectionProxy: ConnectionProxy = mockk()

    // Event notifiers
    private val tunnelState = MutableStateFlow<TunnelState>(TunnelState.Disconnected())

    private val mockAccountRepository: AccountRepository = mockk(relaxed = true)
    private val mockDeviceRepository: DeviceRepository = mockk(relaxed = true)
    private val mockPaymentUseCase: PaymentLogic = mockk(relaxed = true)
    private val mockOutOfTimeUseCase: OutOfTimeUseCase = mockk(relaxed = true)
    private val mockActivityLifecycle: Lifecycle = mockk(relaxed = true)

    private lateinit var viewModel: OutOfTimeViewModel

    @BeforeEach
    fun setup() {
        every { mockConnectionProxy.tunnelState } returns tunnelState

        every { mockAccountRepository.accountData } returns accountExpiryStateFlow

        every { mockDeviceRepository.deviceState } returns accountStateFlow

        coEvery { mockPaymentUseCase.purchaseResult } returns purchaseResultFlow

        coEvery { mockPaymentUseCase.paymentAvailability } returns paymentAvailabilityFlow

        coEvery { mockOutOfTimeUseCase.isOutOfTime } returns outOfTimeFlow

        viewModel =
            OutOfTimeViewModel(
                accountRepository = mockAccountRepository,
                deviceRepository = mockDeviceRepository,
                paymentUseCase = mockPaymentUseCase,
                outOfTimeUseCase = mockOutOfTimeUseCase,
                connectionProxy = mockConnectionProxy,
                activityLifecycle = mockActivityLifecycle,
                isPlayBuild = false,
            )
    }

    @AfterEach
    fun tearDown() {
        unmockkAll()
    }

    @Test
    fun `when clicking on site payment then open website account view`() =
        runAndCancelContextTest(viewModel.viewModelScope.coroutineContext) {
            // Arrange
            val mockToken = WebsiteAuthToken.fromString("154c4cc94810fddac78398662b7fa0c7")
            coEvery { mockAccountRepository.getWebsiteAuthToken() } returns mockToken

            // Act, Assert
            viewModel.uiSideEffect.test {
                viewModel.onSitePaymentClick()
                val action = awaitItem()
                assertIs<OutOfTimeViewModel.UiSideEffect.OpenAccountView>(action)
                assertEquals(mockToken, action.token)
            }
        }

    @Test
    fun `when tunnel state changes then ui should be updated`() =
        runAndCancelContextTest(viewModel.viewModelScope.coroutineContext) {
            // Arrange
            val tunnelRealStateTestItem = TunnelState.Connected(mockk(), mockk(), emptyList())

            // Act, Assert
            viewModel.uiState.test {
                // Default item
                awaitItem()
                tunnelState.emit(tunnelRealStateTestItem)
                val result = awaitItem()
                assertIs<Lc.Content<OutOfTimeUiState>>(result)
                assertEquals(tunnelRealStateTestItem, result.value.tunnelState)
            }
        }

    @Test
    fun `when OutOfTimeUseCase returns false uiSideEffect should emit OpenConnectScreen`() =
        runAndCancelContextTest(viewModel.viewModelScope.coroutineContext) {
            // Act, Assert
            viewModel.uiSideEffect.test {
                outOfTimeFlow.value = false
                val action = awaitItem()
                assertIs<OutOfTimeViewModel.UiSideEffect.OpenConnectScreen>(action)
            }
        }

    @Test
    fun `onDisconnectClick should invoke disconnect on ConnectionProxy`() =
        runAndCancelContextTest(viewModel.viewModelScope.coroutineContext) {
            // Arrange
            val mockDisconnectReason = DisconnectReason.USER_INITIATED_OUT_OF_TIME
            coEvery { mockConnectionProxy.disconnect(any()) } returns true.right()

            // Act
            viewModel.onDisconnectClick()

            // Assert
            coVerify { mockConnectionProxy.disconnect(mockDisconnectReason) }
        }

    @Test
    fun `when there is a pending purchase, uiState should reflect it`() =
        runAndCancelContextTest(viewModel.viewModelScope.coroutineContext) {
            // Arrange
            paymentAvailabilityFlow.value =
                PaymentAvailability.ProductsAvailable(
                    products =
                        listOf(
                            PaymentProduct(
                                productId = ProductId("test_product_id"),
                                price = ProductPrice("9.99"),
                                status = PaymentStatus.PENDING,
                            ),
                        ),
                )

            // Act, Assert
            viewModel.uiState.test {
                val result = awaitItem()
                assertIs<Lc.Content<OutOfTimeUiState>>(result)
                assertEquals(PaymentStatus.PENDING, result.value.paymentStatus)
            }
        }

    companion object {
        private val MOCK_DEVICE =
            Device(id = DeviceId.fromString(UUID), name = "Test Device", creationDate = mockk())
        private const val UUID = "12345678-1234-5678-1234-567812345678"
    }
}
