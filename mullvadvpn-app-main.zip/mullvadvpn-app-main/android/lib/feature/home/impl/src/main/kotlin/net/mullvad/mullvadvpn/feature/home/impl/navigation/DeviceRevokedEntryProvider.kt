package net.mullvad.mullvadvpn.feature.home.impl.navigation

import androidx.navigation3.runtime.EntryProviderScope
import net.mullvad.mullvadvpn.core.NavKey2
import net.mullvad.mullvadvpn.core.Navigator
import net.mullvad.mullvadvpn.feature.home.api.DeviceRevokedNavKey
import net.mullvad.mullvadvpn.feature.home.impl.devicerevoked.DeviceRevoked

internal fun EntryProviderScope<NavKey2>.deviceRevokedEntry(navigator: Navigator) {
    entry<DeviceRevokedNavKey> { DeviceRevoked(navigator = navigator) }
}
