package net.mullvad.mullvadvpn.feature.apiaccess.impl

import app.cash.turbine.test
import arrow.core.left
import arrow.core.right
import io.mockk.coEvery
import io.mockk.mockk
import kotlinx.coroutines.test.runTest
import net.mullvad.mullvadvpn.feature.apiaccess.impl.screen.delete.DeleteApiAccessMethodConfirmationSideEffect
import net.mullvad.mullvadvpn.feature.apiaccess.impl.screen.delete.DeleteApiAccessMethodConfirmationViewModel
import net.mullvad.mullvadvpn.lib.common.test.TestCoroutineRule
import net.mullvad.mullvadvpn.lib.model.ApiAccessMethodId
import net.mullvad.mullvadvpn.lib.model.RemoveApiAccessMethodError
import net.mullvad.mullvadvpn.lib.repository.ApiAccessRepository
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith

@ExtendWith(TestCoroutineRule::class)
class DeleteApiAccessMethodConfirmationViewModelTest {

    private val mockApiAccessRepository: ApiAccessRepository = mockk()
    private lateinit var deleteApiAccessMethodConfirmationViewModel:
        DeleteApiAccessMethodConfirmationViewModel

    @BeforeEach
    fun setUp() {
        val uuid = "12345678-1234-5678-1234-567812345678"
        val apiAccessMethodId = ApiAccessMethodId.fromString(uuid)

        deleteApiAccessMethodConfirmationViewModel =
            DeleteApiAccessMethodConfirmationViewModel(
                apiAccessMethodId = apiAccessMethodId,
                apiAccessRepository = mockApiAccessRepository,
            )
    }

    @Test
    fun `when deleting api access method is successful should update uiSideEffect`() = runTest {
        // Arrange
        coEvery { mockApiAccessRepository.removeApiAccessMethod(any()) } returns Unit.right()

        // Act, Assert
        deleteApiAccessMethodConfirmationViewModel.uiSideEffect.test {
            deleteApiAccessMethodConfirmationViewModel.deleteApiAccessMethod()
            val result = awaitItem()
            assertEquals(DeleteApiAccessMethodConfirmationSideEffect.Deleted, result)
        }
    }

    @Test
    fun `when deleting api access method is not successful should update ui state`() = runTest {
        // Arrange
        val error = RemoveApiAccessMethodError.Unknown(Throwable())
        coEvery { mockApiAccessRepository.removeApiAccessMethod(any()) } returns error.left()

        // Act, Assert
        deleteApiAccessMethodConfirmationViewModel.uiState.test {
            // Default item
            awaitItem()
            deleteApiAccessMethodConfirmationViewModel.deleteApiAccessMethod()
            val result = awaitItem().deleteError
            assertEquals(error, result)
        }
    }
}
