package net.mullvad.mullvadvpn.feature.apiaccess.impl.screen.edit

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.input.InputTransformation
import androidx.compose.foundation.text.input.TextObfuscationMode
import androidx.compose.foundation.text.input.byValue
import androidx.compose.foundation.text.input.rememberTextFieldState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SecureTextField
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldLabelPosition
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.platform.LocalResources
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.tooling.preview.PreviewParameter
import androidx.compose.ui.unit.Dp.Companion.Hairline
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import net.mullvad.mullvadvpn.core.LocalResultStore
import net.mullvad.mullvadvpn.core.Navigator
import net.mullvad.mullvadvpn.feature.apiaccess.api.DiscardApiAccessChangesConfirmedNavResult
import net.mullvad.mullvadvpn.feature.apiaccess.api.DiscardApiAccessChangesNavKey
import net.mullvad.mullvadvpn.feature.apiaccess.api.EditApiAccessMethodNavResult
import net.mullvad.mullvadvpn.feature.apiaccess.api.SaveApiAccessMethodNavKey
import net.mullvad.mullvadvpn.feature.apiaccess.api.SaveApiAccessMethodNavResult
import net.mullvad.mullvadvpn.feature.apiaccess.impl.component.TestMethodButton
import net.mullvad.mullvadvpn.lib.common.compose.CollectSideEffectWithLifecycle
import net.mullvad.mullvadvpn.lib.common.compose.showSnackbarImmediately
import net.mullvad.mullvadvpn.lib.model.ApiAccessMethodId
import net.mullvad.mullvadvpn.lib.model.ApiAccessMethodName
import net.mullvad.mullvadvpn.lib.model.Cipher
import net.mullvad.mullvadvpn.lib.model.InvalidDataError
import net.mullvad.mullvadvpn.lib.ui.component.ScaffoldWithSmallTopBar
import net.mullvad.mullvadvpn.lib.ui.component.button.NavigateCloseIconButton
import net.mullvad.mullvadvpn.lib.ui.component.drawVerticalScrollbar
import net.mullvad.mullvadvpn.lib.ui.component.textfield.ErrorSupportingText
import net.mullvad.mullvadvpn.lib.ui.component.textfield.mullvadDarkTextFieldColors
import net.mullvad.mullvadvpn.lib.ui.designsystem.MullvadCircularProgressIndicatorLarge
import net.mullvad.mullvadvpn.lib.ui.designsystem.MullvadDropdownMenuItem
import net.mullvad.mullvadvpn.lib.ui.designsystem.MullvadExposedDropdownMenuBox
import net.mullvad.mullvadvpn.lib.ui.designsystem.PrimaryButton
import net.mullvad.mullvadvpn.lib.ui.resource.R
import net.mullvad.mullvadvpn.lib.ui.tag.EDIT_API_ACCESS_NAME_INPUT_TEST_TAG
import net.mullvad.mullvadvpn.lib.ui.theme.AppTheme
import net.mullvad.mullvadvpn.lib.ui.theme.Dimens
import net.mullvad.mullvadvpn.lib.ui.theme.color.AlphaInvisible
import net.mullvad.mullvadvpn.lib.ui.theme.color.AlphaScrollbar
import net.mullvad.mullvadvpn.lib.ui.theme.color.AlphaVisible
import net.mullvad.mullvadvpn.lib.ui.util.visible
import org.koin.androidx.compose.koinViewModel
import org.koin.core.parameter.parametersOf

@Preview("Loading|Default|Shadowsocks|Socks5|Socks5Errors")
@Composable
private fun PreviewEditApiAccessMethodScreen(
    @PreviewParameter(EditApiAccessMethodUiStatePreviewParameterProvider::class)
    state: EditApiAccessMethodUiState,
) {
    AppTheme {
        EditApiAccessMethodScreen(
            state = state,
            snackbarHostState = SnackbarHostState(),
            onNameChanged = {},
            onTypeSelected = {},
            onIpChanged = {},
            onPortChanged = {},
            onPasswordChanged = {},
            onCipherChange = {},
            onToggleAuthenticationEnabled = {},
            onUsernameChanged = {},
            onTestMethod = {},
            onAddMethod = {},
            onNavigateBack = {},
        )
    }
}

@Composable
@Suppress("LongMethod")
fun EditApiAccessMethod(apiAccessMethodId: ApiAccessMethodId?, navigator: Navigator) {
    val viewModel = koinViewModel<EditApiAccessMethodViewModel> { parametersOf(apiAccessMethodId) }

    val snackbarHostState = remember { SnackbarHostState() }
    val resources = LocalResources.current
    val scope = rememberCoroutineScope()

    CollectSideEffectWithLifecycle(viewModel.uiSideEffect) {
        when (it) {
            is EditApiAccessSideEffect.OpenSaveDialog ->
                navigator.navigate(
                    SaveApiAccessMethodNavKey(
                        id = it.id,
                        name = it.name,
                        customProxy = it.customProxy,
                    ),
                )

            is EditApiAccessSideEffect.TestApiAccessMethodResult -> {
                launch {
                    snackbarHostState.showSnackbarImmediately(
                        message =
                            resources.getString(
                                if (it.successful) {
                                    R.string.api_reachable
                                } else {
                                    R.string.api_unreachable
                                },
                            ),
                    )
                }
            }
        }
    }

    val resultStore = LocalResultStore.current

    resultStore.consumeResult<SaveApiAccessMethodNavResult> { result ->
        if (result.success) {
            navigator.goBack(result = EditApiAccessMethodNavResult(true))
        } else {
            // Show error snackbar
            scope.launch {
                snackbarHostState.showSnackbarImmediately(
                    message = resources.getString(R.string.error_occurred),
                )
            }
        }
    }

    resultStore.consumeResult<DiscardApiAccessChangesConfirmedNavResult> { navigator.goBack() }

    val state by viewModel.uiState.collectAsStateWithLifecycle()

    LaunchedEffect(state.testingApiAccessMethod()) {
        if (state.testingApiAccessMethod()) {
            launch {
                snackbarHostState.showSnackbarImmediately(
                    message = resources.getString(R.string.testing),
                    duration = SnackbarDuration.Indefinite,
                    actionLabel = resources.getString(R.string.cancel),
                    onAction = viewModel::cancelTestMethod,
                )
            }
        }
    }

    EditApiAccessMethodScreen(
        state = state,
        snackbarHostState = snackbarHostState,
        onNameChanged = viewModel::onNameChanged,
        onTypeSelected = viewModel::setAccessMethodType,
        onIpChanged = viewModel::onServerIpChanged,
        onPortChanged = viewModel::onPortChanged,
        onPasswordChanged = viewModel::onPasswordChanged,
        onCipherChange = viewModel::onCipherChanged,
        onToggleAuthenticationEnabled = viewModel::onAuthenticationEnabledChanged,
        onUsernameChanged = viewModel::onUsernameChanged,
        onTestMethod = viewModel::testMethod,
        onAddMethod = viewModel::trySave,
        onNavigateBack = {
            if (state.hasChanges()) {
                navigator.navigate(DiscardApiAccessChangesNavKey)
            } else {
                navigator.goBack()
            }
        },
    )
}

@Composable
fun EditApiAccessMethodScreen(
    state: EditApiAccessMethodUiState,
    snackbarHostState: SnackbarHostState = SnackbarHostState(),
    onNameChanged: (String) -> Unit,
    onTypeSelected: (ApiAccessMethodTypes) -> Unit,
    onIpChanged: (String) -> Unit,
    onPortChanged: (String) -> Unit,
    onPasswordChanged: (String) -> Unit,
    onCipherChange: (Cipher) -> Unit,
    onToggleAuthenticationEnabled: (Boolean) -> Unit,
    onUsernameChanged: (String) -> Unit,
    onTestMethod: () -> Unit,
    onAddMethod: () -> Unit,
    onNavigateBack: () -> Unit,
) {
    ScaffoldWithSmallTopBar(
        snackbarHostState = snackbarHostState,
        navigationIcon = { NavigateCloseIconButton(onNavigateClose = onNavigateBack) },
        appBarTitle =
            stringResource(
                if (state.editMode) {
                    R.string.edit_method
                } else {
                    R.string.add_method
                },
            ),
    ) { modifier ->
        val scrollState = rememberScrollState()
        Column(
            modifier =
                modifier
                    .drawVerticalScrollbar(
                        state = scrollState,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = AlphaScrollbar),
                    )
                    .verticalScroll(scrollState)
                    .padding(horizontal = Dimens.sideMargin, vertical = Dimens.screenBottomMargin),
        ) {
            when (state) {
                is EditApiAccessMethodUiState.Loading -> Loading()
                is EditApiAccessMethodUiState.Content -> {
                    NameInputField(
                        name = state.formData.name,
                        nameError = state.formData.nameError,
                        onNameChanged = onNameChanged,
                    )
                    Spacer(modifier = Modifier.height(Dimens.formVerticalSpacingGroups))
                    ApiAccessMethodTypeSelection(state.formData, onTypeSelected)
                    Spacer(modifier = Modifier.height(Dimens.formVerticalSpacingGroups))
                    when (state.formData.apiAccessMethodTypes) {
                        ApiAccessMethodTypes.SHADOWSOCKS ->
                            ShadowsocksForm(
                                formData = state.formData,
                                ciphers = state.shadowSocksCiphers,
                                onIpChanged = onIpChanged,
                                onPortChanged = onPortChanged,
                                onPasswordChanged = onPasswordChanged,
                                onCipherChange = onCipherChange,
                            )

                        ApiAccessMethodTypes.SOCKS5_REMOTE ->
                            Socks5RemoteForm(
                                formData = state.formData,
                                onIpChanged = onIpChanged,
                                onPortChanged = onPortChanged,
                                onToggleAuthenticationEnabled = onToggleAuthenticationEnabled,
                                onUsernameChanged = onUsernameChanged,
                                onPasswordChanged = onPasswordChanged,
                            )
                    }
                    Spacer(modifier = Modifier.weight(1f))
                    TestMethodButton(
                        modifier =
                            Modifier.padding(
                                bottom = Dimens.verticalSpace,
                                top = Dimens.largePadding,
                            ),
                        isTesting = state.isTestingApiAccessMethod,
                        onTestMethod = onTestMethod,
                    )
                    AddMethodButton(isNew = !state.editMode, onAddMethod = onAddMethod)
                }
            }
        }
    }
}

@Composable
private fun ColumnScope.Loading() {
    MullvadCircularProgressIndicatorLarge(modifier = Modifier.align(Alignment.CenterHorizontally))
}

@Composable
private fun NameInputField(
    name: String,
    nameError: InvalidDataError.NameError?,
    onNameChanged: (String) -> Unit,
) {
    ApiAccessMethodTextField(
        value = name,
        keyboardType = KeyboardType.Text,
        onValueChanged = onNameChanged,
        labelText = stringResource(id = R.string.name),
        isValidValue = nameError == null,
        inputTransformation =
            InputTransformation.byValue { current, proposed ->
                when {
                    proposed.length > ApiAccessMethodName.MAX_LENGTH -> return@byValue current
                    else -> proposed
                }
            },
        errorText = nameError?.let { stringResource(id = R.string.this_field_is_required) },
        capitalization = KeyboardCapitalization.Words,
        modifier = Modifier.animateContentSize().testTag(EDIT_API_ACCESS_NAME_INPUT_TEST_TAG),
    )
}

@Composable
private fun ApiAccessMethodTypeSelection(
    formData: EditApiAccessFormData,
    onTypeSelected: (ApiAccessMethodTypes) -> Unit,
) {
    MullvadExposedDropdownMenuBox(
        label = stringResource(id = R.string.type),
        title = formData.apiAccessMethodTypes.text(),
        colors = mullvadDarkTextFieldColors(),
    ) { close ->
        ApiAccessMethodTypes.entries.forEachIndexed { index, item ->
            if (index > 0) {
                HorizontalDivider(
                    color = MaterialTheme.colorScheme.outlineVariant,
                    thickness = Hairline,
                )
            }
            MullvadDropdownMenuItem(
                text = item.text(),
                onClick = {
                    close()
                    onTypeSelected(item)
                },
                content = {
                    Icon(
                        imageVector = Icons.Rounded.Check,
                        contentDescription = null,
                        modifier =
                            Modifier.padding(end = Dimens.selectableCellTextMargin)
                                .visible(item == formData.apiAccessMethodTypes),
                    )
                },
            )
        }
    }
}

@Composable
private fun ShadowsocksForm(
    formData: EditApiAccessFormData,
    ciphers: List<Cipher>,
    onIpChanged: (String) -> Unit,
    onPortChanged: (String) -> Unit,
    onPasswordChanged: (String) -> Unit,
    onCipherChange: (Cipher) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(Dimens.formVerticalSpacingInsideGroups)) {
        ServerIpInput(
            serverIp = formData.serverIp,
            serverIpError = formData.serverIpError,
            onIpChanged = onIpChanged,
        )
        PortInput(port = formData.port, formData.portError, onPortChanged = onPortChanged)
        PasswordInput(
            initialPassword = formData.password,
            passwordError = formData.passwordError,
            optional = true,
            onPasswordChanged = onPasswordChanged,
        )
        CipherSelection(
            cipher = formData.cipher,
            ciphers = ciphers,
            onCipherChange = onCipherChange,
        )
    }
}

@Composable
private fun Socks5RemoteForm(
    formData: EditApiAccessFormData,
    onIpChanged: (String) -> Unit,
    onPortChanged: (String) -> Unit,
    onToggleAuthenticationEnabled: (Boolean) -> Unit,
    onUsernameChanged: (String) -> Unit,
    onPasswordChanged: (String) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(Dimens.formVerticalSpacingInsideGroups)) {
        ServerIpInput(
            serverIp = formData.serverIp,
            serverIpError = formData.serverIpError,
            onIpChanged = onIpChanged,
        )
        PortInput(
            port = formData.port,
            portError = formData.portError,
            onPortChanged = onPortChanged,
        )
        EnableAuthentication(formData.enableAuthentication, onToggleAuthenticationEnabled)
        if (formData.enableAuthentication) {
            UsernameInput(
                username = formData.username,
                usernameError = formData.usernameError,
                onUsernameChanged = onUsernameChanged,
            )
            PasswordInput(
                initialPassword = formData.password,
                passwordError = formData.passwordError,
                optional = false,
                onPasswordChanged = onPasswordChanged,
            )
        }
    }
}

@Composable
private fun ServerIpInput(
    serverIp: String,
    serverIpError: InvalidDataError.ServerIpError?,
    onIpChanged: (String) -> Unit,
) {
    ApiAccessMethodTextField(
        value = serverIp,
        keyboardType = KeyboardType.Ascii,
        onValueChanged = onIpChanged,
        labelText = stringResource(id = R.string.server),
        isValidValue = serverIpError == null,
        errorText =
            serverIpError?.let {
                stringResource(
                    id =
                        when (it) {
                            InvalidDataError.ServerIpError.Invalid ->
                                R.string.please_enter_a_valid_ip_address

                            InvalidDataError.ServerIpError.Required ->
                                R.string.this_field_is_required
                        },
                )
            },
        modifier = Modifier.animateContentSize(),
        textStyle = MaterialTheme.typography.bodyLarge.copy(textDirection = TextDirection.Ltr),
    )
}

@Composable
private fun PortInput(
    port: String,
    portError: InvalidDataError.PortError?,
    onPortChanged: (String) -> Unit,
) {
    ApiAccessMethodTextField(
        value = port,
        keyboardType = KeyboardType.Number,
        onValueChanged = onPortChanged,
        labelText = stringResource(id = R.string.port),
        isValidValue = portError == null,
        errorText =
            portError?.let {
                stringResource(
                    id =
                        when (it) {
                            is InvalidDataError.PortError.Invalid ->
                                R.string.please_enter_a_valid_remote_server_port

                            InvalidDataError.PortError.Required -> R.string.this_field_is_required
                        },
                )
            },
        modifier = Modifier.animateContentSize(),
        textStyle = MaterialTheme.typography.bodyLarge.copy(textDirection = TextDirection.Ltr),
    )
}

@Composable
private fun PasswordInput(
    initialPassword: String,
    passwordError: InvalidDataError.PasswordError?,
    optional: Boolean,
    onPasswordChanged: (String) -> Unit,
) {
    val passwordState = rememberTextFieldState(initialPassword)
    LaunchedEffect(passwordState) {
        snapshotFlow { passwordState.text.toString() }.collectLatest { onPasswordChanged(it) }
    }
    var showPassword by remember { mutableStateOf(false) }
    SecureTextField(
        passwordState,
        isError = passwordError != null,
        modifier = Modifier.fillMaxWidth(),
        keyboardOptions =
            KeyboardOptions(
                autoCorrectEnabled = false,
                keyboardType = KeyboardType.Password,
                imeAction =
                    // So that we avoid going back to the name input when pressing done/next
                    if (optional) {
                        ImeAction.Next
                    } else {
                        ImeAction.Done
                    },
            ),
        labelPosition = TextFieldLabelPosition.Above(),
        textObfuscationMode =
            if (showPassword) TextObfuscationMode.Visible else TextObfuscationMode.RevealLastTyped,
        label = {
            Text(
                stringResource(
                    id =
                        if (optional) {
                            R.string.password_optional
                        } else {
                            R.string.password
                        },
                ),
            )
        },
        trailingIcon = {
            IconButton(onClick = { showPassword = !showPassword }) {
                Icon(
                    imageVector =
                        if (showPassword) Icons.Outlined.VisibilityOff
                        else Icons.Outlined.Visibility,
                    contentDescription =
                        if (showPassword) stringResource(id = R.string.hide_account_number)
                        else stringResource(id = R.string.show_account_number),
                )
            }
        },
        supportingText =
            passwordError?.let {
                { ErrorSupportingText(stringResource(id = R.string.this_field_is_required)) }
            },
        colors = mullvadDarkTextFieldColors(),
    )
}

@Composable
private fun CipherSelection(
    cipher: Cipher,
    ciphers: List<Cipher>,
    onCipherChange: (Cipher) -> Unit,
) {
    MullvadExposedDropdownMenuBox(
        label = stringResource(id = R.string.cipher),
        title = cipher.value,
        colors = mullvadDarkTextFieldColors(),
    ) { close ->
        ciphers.forEachIndexed { index, item ->
            if (index > 0) {
                HorizontalDivider(
                    color = MaterialTheme.colorScheme.outlineVariant,
                    thickness = Hairline,
                )
            }
            MullvadDropdownMenuItem(
                text = item.value,
                onClick = {
                    close()
                    onCipherChange(item)
                },
                content = {
                    Icon(
                        imageVector = Icons.Rounded.Check,
                        contentDescription = null,
                        modifier =
                            Modifier.padding(end = Dimens.selectableCellTextMargin)
                                .visible(item == cipher),
                    )
                },
            )
        }
    }
}

@Composable
private fun EnableAuthentication(
    authenticationEnabled: Boolean,
    onToggleAuthenticationEnabled: (Boolean) -> Unit,
) {
    MullvadExposedDropdownMenuBox(
        label = stringResource(id = R.string.authentication),
        title =
            stringResource(
                id =
                    if (authenticationEnabled) {
                        R.string.on
                    } else {
                        R.string.off
                    },
            ),
        colors = mullvadDarkTextFieldColors(),
    ) { close ->
        MullvadDropdownMenuItem(
            text = stringResource(id = R.string.on),
            onClick = {
                close()
                onToggleAuthenticationEnabled(true)
            },
            content = {
                Icon(
                    imageVector = Icons.Rounded.Check,
                    contentDescription = null,
                    modifier =
                        Modifier.padding(end = Dimens.selectableCellTextMargin)
                            .visible(authenticationEnabled),
                )
            },
        )
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant, thickness = Hairline)
        MullvadDropdownMenuItem(
            text = stringResource(id = R.string.off),
            onClick = {
                close()
                onToggleAuthenticationEnabled(false)
            },
            content = {
                Icon(
                    imageVector = Icons.Rounded.Check,
                    contentDescription = null,
                    modifier =
                        Modifier.padding(end = Dimens.selectableCellTextMargin)
                            .alpha(if (authenticationEnabled) AlphaInvisible else AlphaVisible),
                )
            },
        )
    }
}

@Composable
private fun UsernameInput(
    username: String,
    usernameError: InvalidDataError.UserNameError?,
    onUsernameChanged: (String) -> Unit,
) {
    ApiAccessMethodTextField(
        value = username,
        keyboardType = KeyboardType.Text,
        onValueChanged = onUsernameChanged,
        labelText = stringResource(id = R.string.username),
        isValidValue = usernameError == null,
        errorText = usernameError?.let { stringResource(id = R.string.this_field_is_required) },
        modifier = Modifier.animateContentSize(),
        textStyle = MaterialTheme.typography.bodyLarge.copy(textDirection = TextDirection.Ltr),
    )
}

@Composable
private fun AddMethodButton(isNew: Boolean, onAddMethod: () -> Unit) {
    PrimaryButton(
        onClick = onAddMethod,
        text =
            stringResource(
                id =
                    if (isNew) {
                        R.string.add
                    } else {
                        R.string.save
                    },
            ),
    )
}

@Composable
private fun ApiAccessMethodTypes.text(): String =
    stringResource(
        id =
            when (this) {
                ApiAccessMethodTypes.SHADOWSOCKS -> R.string.shadowsocks
                ApiAccessMethodTypes.SOCKS5_REMOTE -> R.string.socks5_remote
            },
    )
