package net.mullvad.mullvadvpn.feature.daita.impl

import app.cash.turbine.test
import arrow.core.right
import io.mockk.coEvery
import io.mockk.coVerify
import io.mockk.every
import io.mockk.mockk
import kotlin.test.assertIs
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.test.runTest
import net.mullvad.mullvadvpn.lib.common.Lc
import net.mullvad.mullvadvpn.lib.common.test.TestCoroutineRule
import net.mullvad.mullvadvpn.lib.model.Settings
import net.mullvad.mullvadvpn.lib.repository.SettingsRepository
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith

@ExtendWith(TestCoroutineRule::class)
class DaitaViewModelTest {
    private val mockSettingsRepository: SettingsRepository = mockk()
    private val settings = MutableStateFlow<Settings>(mockk(relaxed = true))

    private lateinit var viewModel: DaitaViewModel

    @BeforeEach
    fun setUp() {
        every { mockSettingsRepository.settingsUpdates } returns settings
        viewModel = DaitaViewModel(isModal = false, mockSettingsRepository)
    }

    @Test
    fun `given daita enabled ui state should be daita enabled`() = runTest {
        // Arrange
        val expectedState = DaitaUiState(daitaEnabled = true)
        settings.value = mockk {
            every { tunnelOptions.daitaSettings } returns mockk { every { enabled } returns true }
        }

        // Act, Assert
        viewModel.uiState.test {
            val item = awaitItem()
            assertIs<Lc.Content<DaitaUiState>>(item)
            assertEquals(expectedState, item.value)
        }
    }

    @Test
    fun `given direct only enabled ui state should be direct only enabled`() = runTest {
        // Arrange
        val expectedState = DaitaUiState(daitaEnabled = false)
        settings.value = mockk {
            every { tunnelOptions.daitaSettings } returns mockk { every { enabled } returns false }
        }

        // Act, Assert
        viewModel.uiState.test {
            val item = awaitItem()
            assertIs<Lc.Content<DaitaUiState>>(item)
            assertEquals(expectedState, item.value)
        }
    }

    @Test
    fun `set daita should call settings repository set daita enabled`() {
        // Arrange
        coEvery { mockSettingsRepository.setDaitaEnabled(any()) } returns Unit.right()

        // Act
        viewModel.setDaita(true)

        // Assert
        coVerify { mockSettingsRepository.setDaitaEnabled(true) }
    }
}
