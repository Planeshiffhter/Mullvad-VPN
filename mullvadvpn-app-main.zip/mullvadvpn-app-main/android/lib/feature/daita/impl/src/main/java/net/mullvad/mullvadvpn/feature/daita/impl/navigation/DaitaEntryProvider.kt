package net.mullvad.mullvadvpn.feature.daita.impl.navigation

import androidx.navigation3.runtime.EntryProviderScope
import androidx.navigation3.ui.LocalNavAnimatedContentScope
import net.mullvad.mullvadvpn.core.NavKey2
import net.mullvad.mullvadvpn.core.Navigator
import net.mullvad.mullvadvpn.core.animation.slideInHorizontalTransition
import net.mullvad.mullvadvpn.core.scene.ListDetailSceneStrategy
import net.mullvad.mullvadvpn.feature.daita.api.DaitaNavKey
import net.mullvad.mullvadvpn.feature.daita.impl.Daita
import net.mullvad.mullvadvpn.lib.common.compose.LocalSharedTransitionScope

fun EntryProviderScope<NavKey2>.daitaEntry(navigator: Navigator) {
    entry<DaitaNavKey>(
        metadata = ListDetailSceneStrategy.detailPane() + slideInHorizontalTransition(),
    ) { navKey ->
        LocalSharedTransitionScope.current?.Daita(
            navigator = navigator,
            isModal = navKey.isModal,
            animatedVisibilityScope = LocalNavAnimatedContentScope.current,
        )
    }
}
