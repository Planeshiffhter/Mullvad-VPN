package net.mullvad.mullvadvpn.feature.addtime.impl

import android.app.Activity
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.WhileSubscribed
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import net.mullvad.mullvadvpn.feature.addtime.impl.AddMoreTimeSideEffect.OpenAccountManagementPageInBrowser
import net.mullvad.mullvadvpn.lib.common.Lc
import net.mullvad.mullvadvpn.lib.common.constant.VIEW_MODEL_STOP_TIMEOUT
import net.mullvad.mullvadvpn.lib.model.WebsiteAuthToken
import net.mullvad.mullvadvpn.lib.payment.model.ProductId
import net.mullvad.mullvadvpn.lib.payment.model.PurchaseResult
import net.mullvad.mullvadvpn.lib.payment.util.isSuccess
import net.mullvad.mullvadvpn.lib.repository.AccountRepository
import net.mullvad.mullvadvpn.lib.repository.ConnectionProxy
import net.mullvad.mullvadvpn.lib.repository.PaymentLogic

class AddTimeViewModel(
    private val paymentUseCase: PaymentLogic,
    private val accountRepository: AccountRepository,
    connectionProxy: ConnectionProxy,
    isPlayBuild: Boolean,
) : ViewModel() {
    private val _uiSideEffect = Channel<AddMoreTimeSideEffect>()
    val uiSideEffect = _uiSideEffect.receiveAsFlow()

    val uiState: StateFlow<Lc<Unit, AddTimeUiState>> =
        combine(
                paymentUseCase.paymentAvailability.filterNotNull(),
                paymentUseCase.purchaseResult,
                connectionProxy.tunnelState,
            ) { paymentAvailability, purchaseResult, tunnelState ->
                Lc.Content(
                    AddTimeUiState(
                        purchaseState = purchaseResult?.toPurchaseState(),
                        billingPaymentState = paymentAvailability.toPaymentState(),
                        tunnelStateBlocked = tunnelState.isBlocked(),
                        showSitePayment = !isPlayBuild,
                    ),
                )
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(VIEW_MODEL_STOP_TIMEOUT),
                initialValue = Lc.Loading(Unit),
            )

    init {
        verifyPurchases()
        fetchPaymentAvailability()
        handlePurchaseResultTerminatingState()
    }

    fun onManageAccountClick() {
        viewModelScope.launch {
            val wwwAuthToken = accountRepository.getWebsiteAuthToken()
            _uiSideEffect.send(OpenAccountManagementPageInBrowser(wwwAuthToken))
        }
    }

    fun fetchPaymentAvailability() {
        viewModelScope.launch { paymentUseCase.queryPaymentAvailability() }
    }

    fun startBillingPayment(productId: ProductId, activityProvider: () -> Activity) {
        viewModelScope.launch { paymentUseCase.purchaseProduct(productId, activityProvider) }
    }

    fun resetPurchaseResult() {
        viewModelScope.launch { paymentUseCase.resetPurchaseResult() }
    }

    private fun verifyPurchases() {
        viewModelScope.launch {
            if (paymentUseCase.verifyPurchases().isSuccess()) {
                updateAccountExpiry()
            }
        }
    }

    fun retryVerifyPurchase() {
        viewModelScope.launch {
            if (paymentUseCase.retryVerifyPurchase().isSuccess()) {
                updateAccountExpiry()
            }
        }
    }

    private fun handlePurchaseResultTerminatingState() {
        viewModelScope.launch {
            paymentUseCase.purchaseResult
                // Terminating states are either errors or completed purchases.
                .filter { it?.isTerminatingState() == true }
                .collect {
                    // If did a successful purchase we should fetch the new added time
                    if (it is PurchaseResult.Completed.Success) {
                        updateAccountExpiry()
                    } else {
                        // Otherwise update payment availability to check for pending purchases
                        fetchPaymentAvailability()
                        // Check if we have any non-verified purchase
                        verifyPurchases()
                    }
                }
        }
    }

    private fun updateAccountExpiry() {
        viewModelScope.launch { accountRepository.fetchAccountData() }
    }

    private fun PurchaseResult.toPurchaseState() =
        when (this) {
            // Idle states
            PurchaseResult.Completed.Cancelled,
            PurchaseResult.BillingFlowStarted,
            is PurchaseResult.Error.BillingError -> {
                // Show nothing
                null
            }
            // Fetching products and obfuscated id loading state
            PurchaseResult.FetchingProducts,
            PurchaseResult.FetchingObfuscationId -> PurchaseState.Connecting
            // Verifying loading states
            PurchaseResult.VerificationStarted -> PurchaseState.VerificationStarted
            // Pending state
            is PurchaseResult.Completed.Pending -> PurchaseState.VerifyingPurchase
            // Success state
            is PurchaseResult.Completed.Success -> PurchaseState.Success(productId)
            // Error states
            is PurchaseResult.Error.TransactionIdError ->
                PurchaseState.Error.TransactionIdError(productId = productId)
            is PurchaseResult.Error.FetchProductsError ->
                PurchaseState.Error.OtherError(productId = productId)
            is PurchaseResult.Error.NoProductFound ->
                PurchaseState.Error.OtherError(productId = productId)
            is PurchaseResult.Error.VerificationError.VerificationFailed ->
                PurchaseState.Error.VerificationError.Unrecoverable
            is PurchaseResult.Error.VerificationError.Other,
            is PurchaseResult.Error.VerificationError.ApiUnreachable ->
                PurchaseState.Error.VerificationError.Recoverable
        }
}

sealed interface AddMoreTimeSideEffect {
    data class OpenAccountManagementPageInBrowser(val token: WebsiteAuthToken?) :
        AddMoreTimeSideEffect
}
