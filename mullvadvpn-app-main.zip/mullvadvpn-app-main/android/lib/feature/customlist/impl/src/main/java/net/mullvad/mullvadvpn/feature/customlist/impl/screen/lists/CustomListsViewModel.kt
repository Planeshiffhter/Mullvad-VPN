package net.mullvad.mullvadvpn.feature.customlist.impl.screen.lists

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.WhileSubscribed
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import net.mullvad.mullvadvpn.lib.common.constant.VIEW_MODEL_STOP_TIMEOUT
import net.mullvad.mullvadvpn.lib.model.communication.CustomListAction
import net.mullvad.mullvadvpn.lib.repository.CustomListsRepository
import net.mullvad.mullvadvpn.lib.usecase.customlists.CustomListActionUseCase

class CustomListsViewModel(
    customListsRepository: CustomListsRepository,
    private val customListActionUseCase: CustomListActionUseCase,
) : ViewModel() {

    val uiState =
        customListsRepository.customLists
            .filterNotNull()
            .map(CustomListsUiState::Content)
            .stateIn(
                viewModelScope,
                started = SharingStarted.WhileSubscribed(VIEW_MODEL_STOP_TIMEOUT),
                CustomListsUiState.Loading,
            )

    fun undoDeleteCustomList(action: CustomListAction.Create) {
        viewModelScope.launch { customListActionUseCase(action) }
    }
}
