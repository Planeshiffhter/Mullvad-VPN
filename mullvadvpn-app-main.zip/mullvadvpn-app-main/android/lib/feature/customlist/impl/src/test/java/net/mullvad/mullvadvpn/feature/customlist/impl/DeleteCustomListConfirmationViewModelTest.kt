package net.mullvad.mullvadvpn.feature.customlist.impl

import app.cash.turbine.test
import arrow.core.right
import io.mockk.coEvery
import io.mockk.every
import io.mockk.mockk
import kotlin.test.assertIs
import kotlinx.coroutines.test.runTest
import net.mullvad.mullvadvpn.feature.customlist.api.DeleteCustomListNavKey
import net.mullvad.mullvadvpn.feature.customlist.impl.screen.delete.DeleteCustomListConfirmationSideEffect
import net.mullvad.mullvadvpn.feature.customlist.impl.screen.delete.DeleteCustomListConfirmationViewModel
import net.mullvad.mullvadvpn.lib.common.test.TestCoroutineRule
import net.mullvad.mullvadvpn.lib.model.CustomListId
import net.mullvad.mullvadvpn.lib.model.CustomListName
import net.mullvad.mullvadvpn.lib.model.communication.CustomListAction
import net.mullvad.mullvadvpn.lib.model.communication.CustomListActionResultData
import net.mullvad.mullvadvpn.lib.model.communication.Deleted
import net.mullvad.mullvadvpn.lib.usecase.customlists.CustomListActionUseCase
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith

@ExtendWith(TestCoroutineRule::class)
class DeleteCustomListConfirmationViewModelTest {
    private val mockCustomListActionUseCase: CustomListActionUseCase = mockk()

    @Test
    fun `when successfully deleting a list should emit return with result side effect`() = runTest {
        // Arrange
        val deleted: Deleted = mockk()
        val customListName = CustomListName.fromString("name")
        val undo: CustomListAction.Create = mockk()
        val expectedResult =
            CustomListActionResultData.Success.Deleted(customListName = customListName, undo = undo)
        every { deleted.name } returns customListName
        every { deleted.undo } returns undo
        val viewModel = createViewModel()
        coEvery { mockCustomListActionUseCase(any<CustomListAction.Delete>()) } returns
            deleted.right()

        // Act, Assert
        viewModel.uiSideEffect.test {
            viewModel.deleteCustomList()
            val sideEffect = awaitItem()
            assertIs<DeleteCustomListConfirmationSideEffect.ReturnWithResult>(sideEffect)
            assertEquals(expectedResult, sideEffect.result)
        }
    }

    private fun createViewModel() =
        DeleteCustomListConfirmationViewModel(
            navArgs =
                DeleteCustomListNavKey(
                    customListId = CustomListId("1"),
                    name = CustomListName.fromString("asdf"),
                ),
            customListActionUseCase = mockCustomListActionUseCase,
        )
}
