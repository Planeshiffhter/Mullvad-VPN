#ifndef GATEWAYCONTROLLER_H
#define GATEWAYCONTROLLER_H

#include <QByteArray>
#include <QFuture>
#include <QJsonObject>
#include <QObject>
#include <QPair>
#include <QString>
#include <QStringList>

#include "core/utils/commonStructs.h"
#include "core/utils/errorCodes.h"

#include "agw.h"

class SecureAppSettingsRepository;

class GatewayController : public QObject
{
    Q_OBJECT

public:
    explicit GatewayController(const amnezia::GatewayEnvironment &environment, const int requestTimeoutMsecs,
                               const bool isStrictKillSwitchEnabled, SecureAppSettingsRepository *appSettingsRepository,
                               QObject *parent = nullptr);
    ~GatewayController() override;

    amnezia::ErrorCode post(const QString &endpoint, const QJsonObject apiPayload, QByteArray &responseBody);
    QFuture<QPair<amnezia::ErrorCode, QByteArray>> postAsync(const QString &endpoint, const QJsonObject apiPayload);

private:
    void prepareRequest();
    QStringList requestHosts() const;

    QPair<amnezia::ErrorCode, QByteArray> executePost(const QString &endpoint, const QJsonObject &apiPayload);
    static amnezia::ErrorCode mapResultCode(const int code, const QByteArray &responseBody);
    void persistState();

    QString m_gatewayEndpoint;
    bool m_isStrictKillSwitchEnabled = false;
    SecureAppSettingsRepository *m_appSettingsRepository = nullptr;

    agw_client_handle m_client = 0;
    bool m_publicKeyMissing = false;
    QByteArray m_lastPersistedState;
};

#endif // GATEWAYCONTROLLER_H
